<?php
/**
 * 本地冒烟：语法检查、种子用户、灯具库、CSRF、mock 检索、上传 MIME、上传目录。
 * 用法：php scripts/smoke.php
 */
declare(strict_types=1);

$root = dirname(__DIR__);
$failures = 0;

function ok(string $msg): void
{
    echo "[OK] $msg\n";
}
function fail(string $msg): void
{
    global $failures;
    $failures++;
    echo "[FAIL] $msg\n";
}

require $root . '/src/bootstrap.php';

// 1) php -l 所有 PHP
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
foreach ($iterator as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }
    $path = $file->getPathname();
    if (str_contains($path, DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR)) {
        continue;
    }
    $out = [];
    $code = 0;
    exec('php -l ' . escapeshellarg($path) . ' 2>&1', $out, $code);
    if ($code !== 0) {
        fail('php -l ' . $path . ': ' . implode(' ', $out));
    }
}
ok('全部 PHP 语法检查通过');

$stmt = $pdo->prepare('SELECT username, password_hash FROM users WHERE username = ?');
$stmt->execute(['admin']);
$row = $stmt->fetch();
if (!$row) {
    fail('未找到种子用户 admin');
} elseif (!password_verify('ChangeMe123!', $row['password_hash'])) {
    fail('admin 密码哈希与 ChangeMe123! 不匹配');
} else {
    ok('种子管理员 admin / ChangeMe123! 可用');
}

// products 表与种子灯具
try {
    $pCount = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
    if ($pCount < 1) {
        fail('products 表应至少有种子灯具');
    } else {
        ok("products 灯具库有 {$pCount} 条记录");
    }
    $cols = $pdo->query('PRAGMA table_info(products)')->fetchAll();
    $colNames = array_column($cols, 'name');
    foreach (['id', 'name', 'model', 'sku', 'price', 'currency', 'category', 'brand', 'series', 'specs_json', 'image_stored_name', 'source', 'created_at', 'updated_at'] as $need) {
        if (!in_array($need, $colNames, true)) {
            fail("products 缺少列: {$need}");
        }
    }
    ok('products 表结构字段齐全');
    $imgTable = (int) $pdo->query(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='product_images'"
    )->fetchColumn();
    if ($imgTable !== 1) {
        fail('缺少 product_images 表');
    } else {
        ok('product_images 表存在');
    }
} catch (Throwable $ex) {
    fail('products 检查失败: ' . $ex->getMessage());
}

$token = Csrf::token();
if (!Csrf::validate($token)) {
    fail('CSRF 校验异常');
} else {
    ok('CSRF 正常');
}

$search = new ImageSearch($config, $pdo);
$mock = $search->searchSimilar('/tmp/does-not-matter.jpg', 3);
if (count($mock) !== 3) {
    fail('mock 检索应返回 3 条');
} else {
    $src = $mock[0]['source'] ?? '';
    ok('ImageSearch mock 返回 ' . count($mock) . ' 条（source=' . $src . '）');
}

// 上传限制与查询 MIME
$max = (int) ($config['upload_max_bytes'] ?? 0);
if ($max < 50 * 1024 * 1024) {
    fail('upload_max_bytes 应 >= 50MB，当前 ' . $max);
} else {
    ok('upload_max_bytes = ' . round($max / 1048576) . 'MB');
}
$queryExt = $config['query_allowed_ext'] ?? [];
foreach (['jpg', 'png', 'pdf', 'xlsx', 'docx', 'zip'] as $ext) {
    if (!in_array($ext, $queryExt, true)) {
        fail("query_allowed_ext 缺少 {$ext}");
    }
}
ok('query_allowed_ext 含图片/PDF/Excel/Word/ZIP');

$imgMime = $config['upload_allowed_mime'] ?? [];
if (!in_array('image/jpeg', $imgMime, true)) {
    fail('产品图 MIME 应含 image/jpeg');
} else {
    ok('产品图入库 MIME 限制正常');
}

// kindFromExt
if (Upload::kindFromExt('pdf') !== 'pdf' || Upload::kindFromExt('docx') !== 'word') {
    fail('Upload::kindFromExt 异常');
} else {
    ok('Upload::kindFromExt 正常');
}

$dir = $config['upload_dir'];
if (!is_dir($dir) && !mkdir($dir, 0750, true)) {
    fail('无法创建上传目录');
} elseif (!is_writable($dir)) {
    fail('上传目录不可写: ' . $dir);
} else {
    ok('上传目录可写');
}

// 模拟保存一张小 PNG（非 HTTP 上传路径）
$png = $dir . DIRECTORY_SEPARATOR . '_smoke_src.png';
// 1x1 PNG
$bin = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==');
file_put_contents($png, $bin);
try {
    $saved = Upload::saveQueryFile([
        'name' => 'smoke.png',
        'type' => 'image/png',
        'tmp_name' => $png,
        'error' => UPLOAD_ERR_OK,
        'size' => filesize($png),
    ], $config);
    if (($saved['kind'] ?? '') !== 'image' || empty($saved['stored_name'])) {
        fail('saveQueryFile 图片结果异常');
    } else {
        ok('saveQueryFile 图片 OK → ' . $saved['stored_name']);
        @unlink($config['upload_dir'] . DIRECTORY_SEPARATOR . $saved['stored_name']);
    }
} catch (Throwable $ex) {
    fail('saveQueryFile: ' . $ex->getMessage());
}

echo $failures === 0 ? "\n冒烟通过。本地启动：php -S localhost:8080 -t public\n" : "\n冒烟失败：$failures 项\n";
exit($failures === 0 ? 0 : 1);
