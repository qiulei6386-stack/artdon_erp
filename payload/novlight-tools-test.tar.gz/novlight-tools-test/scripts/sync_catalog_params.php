<?php
declare(strict_types=1);

/**
 * 用 2026-2027 目录核对过的参数（data/seed/catalog_2026_2027.json）校正产品库。
 *
 *   php scripts/sync_catalog_params.php           只列出会改哪些（不改）
 *   php scripts/sync_catalog_params.php --apply   真正写入
 *
 * 只改参数文字列（开孔、尺寸、功率、光通量、调节、光束角、色温、显指、UGR、调光、IP、适用场景）
 * 和由它们算出的数字列；名称、价格、图片、备注不动。库里没有的型号不会新增。
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/src/bootstrap.php';

$apply = in_array('--apply', $argv, true);
$seedFile = dirname(__DIR__) . '/data/seed/catalog_2026_2027.json';
$seed = json_decode((string) file_get_contents($seedFile), true);
if (!is_array($seed)) {
    fwrite(STDERR, "读不出 {$seedFile}\n");
    exit(1);
}

$cols = ['cut_out', 'dimensions', 'power', 'luminous_flux', 'adjustability', 'adaptor', 'beam_angle', 'cct', 'cri', 'ugr', 'dimming_method', 'ip_rating', 'best_for'];
$find = $pdo->prepare('SELECT * FROM products WHERE model = ?');
$changedProducts = 0;
$changedFields = 0;
$missing = [];
if ($apply) {
    $pdo->beginTransaction();
}
foreach ($seed as $s) {
    $find->execute([$s['model']]);
    $row = $find->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        $missing[] = $s['model'];
        continue;
    }
    $set = [];
    foreach ($cols as $c) {
        $new = trim((string) ($s[$c] ?? ''));
        $old = trim((string) ($row[$c] ?? ''));
        if ($old === '--') {
            $old = '';
        }
        if ($new !== $old) {
            $set[$c] = $new;
            fwrite(STDOUT, sprintf("%-10s %-14s %s  →  %s\n", $s['model'], $c, $old === '' ? '（空）' : $old, $new === '' ? '（空）' : $new));
        }
    }
    if (!$set) {
        continue;
    }
    $changedProducts++;
    $changedFields += count($set);
    if (!$apply) {
        continue;
    }
    if (isset($set['power']) && preg_match('/(\d+(?:\.\d+)?)\s*W(?:\s+(\d+V))?(?:\s+(\d+mA))?/i', $set['power'], $m)) {
        $set['power_watts'] = (float) $m[1];
        $set['voltage'] = $m[2] ?? '';
        $set['drive_current'] = $m[3] ?? '';
    }
    $set['updated_at'] = date('Y-m-d H:i:s');
    $sql = 'UPDATE products SET ' . implode(', ', array_map(static function ($k) {
        return $k . ' = :' . $k;
    }, array_keys($set))) . ' WHERE id = :id';
    $params = [':id' => (int) $row['id']];
    foreach ($set as $k => $v) {
        $params[':' . $k] = $v;
    }
    $pdo->prepare($sql)->execute($params);
    $find->execute([$s['model']]);
    ProductParams::save($pdo, (int) $row['id'], ProductParams::derive((array) $find->fetch(PDO::FETCH_ASSOC)));
}
if ($apply) {
    $pdo->commit();
}
fwrite(STDOUT, "\n目录型号 " . count($seed) . " 个；需要校正 {$changedProducts} 个型号、{$changedFields} 处参数。");
if ($missing) {
    fwrite(STDOUT, "\n产品库里没有的型号（未新增）：" . implode('、', $missing));
}
fwrite(STDOUT, $apply ? "\n已写入。\n" : "\n这是预览，没有改动。确认后加 --apply 再运行一次。\n");
