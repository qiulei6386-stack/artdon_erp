<?php
/**
 * Batch CreateImage for products that have primary images.
 * Usage (server): /www/server/php/80/bin/php scripts/reindex_tencent.php [--source=自制产品] [--limit=N] [--sleep-ms=200]
 */
declare(strict_types=1);

$root = dirname(__DIR__);
require $root . '/src/bootstrap.php';

$opts = getopt('', ['source::', 'limit::', 'offset::', 'sleep-ms::', 'ids::', 'dry-run', 'no-fallback', 'force', 'all-sources']);
$source = isset($opts['source']) ? (string) $opts['source'] : '自制产品';
if (array_key_exists('all-sources', $opts)) {
    $source = '';
}
$limit = isset($opts['limit']) ? (int) $opts['limit'] : 0;
$offset = isset($opts['offset']) ? max(0, (int) $opts['offset']) : 0;
$sleepMs = isset($opts['sleep-ms']) ? (int) $opts['sleep-ms'] : 250;
$dry = array_key_exists('dry-run', $opts);
$noFallback = array_key_exists('no-fallback', $opts);
$force = array_key_exists('force', $opts);
$idFilter = [];
if (isset($opts['ids']) && (string) $opts['ids'] !== '') {
    foreach (preg_split('/[\s,]+/', (string) $opts['ids']) as $tok) {
        $tok = trim($tok);
        if ($tok !== '' && ctype_digit($tok)) {
            $idFilter[] = (int) $tok;
        }
    }
    $idFilter = array_values(array_unique($idFilter));
}
if ($noFallback) {
    $config['image_search']['fallback_mock'] = false;
}

$sql = 'SELECT id, name, model, price, image_stored_name, source
        FROM products
        WHERE image_stored_name != \'\'';
$params = [];
if ($source !== '') {
    $sql .= ' AND source = :src';
    $params[':src'] = $source;
}
if ($idFilter !== []) {
    $sql .= ' AND id IN (' . implode(',', array_map('intval', $idFilter)) . ')';
}
$sql .= ' ORDER BY id ASC';
if ($limit > 0) {
    $sql .= ' LIMIT ' . $limit;
    if ($offset > 0) {
        $sql .= ' OFFSET ' . $offset;
    }
} elseif ($offset > 0) {
    $sql .= ' LIMIT -1 OFFSET ' . $offset;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$search = new ImageSearch($config, $pdo);
$ok = 0;
$fail = 0;
$skip = 0;

fwrite(STDOUT, 'provider=' . ($config['image_search_provider'] ?? '') . " rows=" . count($rows) . "\n");

foreach ($rows as $row) {
    $abs = $config['upload_dir'] . DIRECTORY_SEPARATOR . $row['image_stored_name'];
    if (!is_readable($abs)) {
        fwrite(STDOUT, "SKIP id={$row['id']} missing file {$row['image_stored_name']}\n");
        $skip++;
        continue;
    }
    if ($dry) {
        fwrite(STDOUT, "DRY id={$row['id']} model={$row['model']}\n");
        $ok++;
        continue;
    }
    try {
        $meta = [
            'product_id' => (int) $row['id'],
            'product_name' => (string) $row['name'],
            'product_model' => (string) $row['model'],
            'price' => (float) $row['price'],
        ];
        if ($force) {
            $meta['force_reindex'] = true;
        }
        $indexed = $search->indexImage($abs, $meta);
        if ($indexed) {
            $ok++;
            fwrite(STDOUT, "OK id={$row['id']} model={$row['model']}\n");
        } else {
            $fail++;
            fwrite(STDOUT, "FAIL(fallback) id={$row['id']} model={$row['model']}\n");
        }
    } catch (Throwable $ex) {
        $fail++;
        fwrite(STDOUT, "ERR id={$row['id']} " . $ex->getMessage() . "\n");
    }
    $done = $ok + $fail + $skip;
    if ($done % 20 === 0) {
        fwrite(STDOUT, "PROGRESS done={$done} ok={$ok} fail={$fail} skip={$skip}\n");
    }
    if ($sleepMs > 0) {
        usleep($sleepMs * 1000);
    }
}

fwrite(STDOUT, json_encode(['ok' => $ok, 'fail' => $fail, 'skip' => $skip], JSON_UNESCAPED_UNICODE) . "\n");
