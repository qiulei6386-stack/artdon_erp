<?php
declare(strict_types=1);
/**
 * Server smoke: DescribeGroups + CreateGroup(novlight_lighting, type 4).
 * Never prints secret values.
 */
$root = '/www/wwwroot/novlight-tools';
require $root . '/src/TencentTiiaClient.php';
$config = require $root . '/config.php';

$provider = $config['image_search_provider'] ?? '';
echo "provider=" . $provider . "\n";

$base = $config['image_search']['tencent'] ?? [];
$secretsFile = $config['tencent_secrets_file'] ?? '';
$secretId = (string)($base['secret_id'] ?? '');
$secretKey = (string)($base['secret_key'] ?? '');
$region = (string)($base['region'] ?? 'ap-guangzhou');
if (($secretId === '' || $secretKey === '') && $secretsFile !== '' && is_readable($secretsFile)) {
    $loaded = include $secretsFile;
    if (is_array($loaded)) {
        if ($secretId === '' && !empty($loaded['secret_id'])) $secretId = (string)$loaded['secret_id'];
        if ($secretKey === '' && !empty($loaded['secret_key'])) $secretKey = (string)$loaded['secret_key'];
        if (!empty($loaded['region'])) $region = (string)$loaded['region'];
    }
}

echo "secrets_file_readable=" . (is_readable($secretsFile) ? 'yes' : 'no') . "\n";
echo "secret_id_len=" . strlen($secretId) . " secret_key_len=" . strlen($secretKey) . " region=" . $region . "\n";
echo "group_id=" . ($base['group_id'] ?? '') . " group_type=" . ($base['group_type'] ?? '') . "\n";

if ($secretId === '' || $secretKey === '') {
    fwrite(STDERR, "FAIL: secrets empty\n");
    exit(2);
}

$client = new TencentTiiaClient([
    'secret_id' => $secretId,
    'secret_key' => $secretKey,
    'region' => $region,
    'group_id' => (string)($base['group_id'] ?? 'novlight_lighting'),
    'group_type' => (int)($base['group_type'] ?? 4),
    'max_capacity' => (int)($base['max_capacity'] ?? 10000),
]);

echo "=== DescribeGroups (before) ===\n";
try {
    $before = $client->describeGroups(0, 50);
    $groups = $before['Groups'] ?? $before['GroupInfos'] ?? [];
    echo "count=" . (is_array($groups) ? count($groups) : 0) . "\n";
    if (is_array($groups)) {
        foreach ($groups as $g) {
            if (!is_array($g)) continue;
            $gid = $g['GroupId'] ?? $g['GroupID'] ?? '';
            $gt = $g['GroupType'] ?? '';
            $cap = $g['MaxCapacity'] ?? '';
            $used = $g['PicCount'] ?? $g['ImageCount'] ?? $g['GroupCount'] ?? '';
            echo "  GroupId={$gid} GroupType={$gt} MaxCapacity={$cap} PicOrCount={$used}\n";
        }
    }
    echo "RequestId=" . ($before['RequestId'] ?? '') . "\n";
} catch (Throwable $ex) {
    echo "DescribeGroups ERROR: " . $ex->getMessage() . "\n";
}

echo "=== CreateGroupIfNeeded ===\n";
try {
    $client->createGroupIfNeeded();
    echo "CreateGroupIfNeeded: OK (created or already existed)\n";
} catch (Throwable $ex) {
    echo "CreateGroup ERROR: " . $ex->getMessage() . "\n";
    exit(3);
}

echo "=== DescribeGroups (after) ===\n";
try {
    $after = $client->describeGroups(0, 50);
    $groups = $after['Groups'] ?? $after['GroupInfos'] ?? [];
    $found = false;
    if (is_array($groups)) {
        foreach ($groups as $g) {
            if (!is_array($g)) continue;
            $gid = (string)($g['GroupId'] ?? $g['GroupID'] ?? '');
            $gt = $g['GroupType'] ?? '';
            $cap = $g['MaxCapacity'] ?? '';
            $used = $g['PicCount'] ?? $g['ImageCount'] ?? '';
            echo "  GroupId={$gid} GroupType={$gt} MaxCapacity={$cap} PicOrCount={$used}\n";
            if ($gid === 'novlight_lighting') $found = true;
        }
    }
    echo "novlight_lighting_present=" . ($found ? 'yes' : 'no') . "\n";
    echo "RequestId=" . ($after['RequestId'] ?? '') . "\n";
} catch (Throwable $ex) {
    echo "DescribeGroups(after) ERROR: " . $ex->getMessage() . "\n";
    exit(4);
}

echo "DONE\n";
