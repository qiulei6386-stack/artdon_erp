<section class="page-head">
  <h1>功能菜单</h1>
  <p class="muted">选择要使用的工具</p>
</section>

<div class="menu-grid">
  <a class="tool-card" href="index.php?r=selection">
    <div class="tool-icon" aria-hidden="true">◎</div>
    <h2>自动选型系统</h2>
    <p>上传客户/现场图片，检索相似产品并生成报价摘要</p>
  </a>
  <a class="tool-card" href="index.php?r=catalog">
    <div class="tool-icon" aria-hidden="true">＋</div>
    <h2>产品图入库</h2>
    <p>维护选型图库：上传产品图与名称、型号、价格</p>
  </a>
</div>
