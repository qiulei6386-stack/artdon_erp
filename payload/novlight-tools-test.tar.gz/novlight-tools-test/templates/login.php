<section class="card login-card">
  <h1>登录</h1>
  <p class="muted">员工使用电脑浏览器访问 · 登录后进入功能菜单</p>
  <form method="post" action="index.php?r=login" class="form" autocomplete="on">
    <?= Csrf::field() ?>
    <label>
      <span>用户名</span>
      <input type="text" name="username" required autofocus autocomplete="username">
    </label>
    <label>
      <span>密码</span>
      <input type="password" name="password" required autocomplete="current-password">
    </label>
    <button type="submit" class="btn btn-primary">登录</button>
  </form>
</section>
