<?php
/** @var array $run */
/** @var array<int, array> $products */
/** @var array|null $quote */

$fmt = static function ($v, string $unit = ''): string {
    if ($v === null || $v === '' || $v === []) {
        return '';
    }
    return SpecMatcher::fmt((float) $v) . $unit;
};
$typeLabel = static function (string $t): string {
    return ProductParams::TYPES[$t] ?? $t;
};
$chips = static function (array $it) use ($fmt): array {
    $c = [];
    if ($fmt($it['cutout_mm'] ?? null) !== '') {
        $c[] = '开孔 ' . $fmt($it['cutout_mm'], 'mm');
    }
    $size = array_filter([$fmt($it['diameter_mm'] ?? null), $fmt($it['length_mm'] ?? null), $fmt($it['height_mm'] ?? null)]);
    if ($size) {
        $c[] = '尺寸 ' . implode('×', $size) . 'mm';
    }
    if ($fmt($it['watt'] ?? null) !== '') {
        $c[] = $fmt($it['watt'], 'W');
    }
    if ($fmt($it['lumen'] ?? null) !== '') {
        $c[] = $fmt($it['lumen'], 'lm');
    }
    if (!empty($it['adjustable'])) {
        $c[] = '可调' . ($fmt($it['tilt_deg'] ?? null) !== '' ? ' ' . $fmt($it['tilt_deg'], '°') : '') . ($fmt($it['rotation_deg'] ?? null) !== '' ? ' / 旋转 ' . $fmt($it['rotation_deg'], '°') : '');
    } elseif (isset($it['adjustable']) && $it['adjustable'] === false) {
        $c[] = '固定';
    }
    if (!empty($it['beam_angles'])) {
        $c[] = '光束 ' . implode('/', array_map(static function ($b) use ($fmt) {
            return $fmt($b, '°');
        }, $it['beam_angles']));
    }
    if (!empty($it['cct'])) {
        $c[] = implode('/', array_map(static function ($b) use ($fmt) {
            return $fmt($b, 'K');
        }, $it['cct']));
    }
    if ($fmt($it['cri'] ?? null) !== '') {
        $c[] = 'Ra' . $fmt($it['cri']) . '+';
    }
    if ($fmt($it['ugr_max'] ?? null) !== '') {
        $c[] = 'UGR<' . $fmt($it['ugr_max']);
    }
    if ($fmt($it['ip'] ?? null) !== '') {
        $c[] = 'IP' . $fmt($it['ip']);
    }
    if (!empty($it['dimming'])) {
        $c[] = implode(' / ', $it['dimming']);
    }
    return $c;
};
$items = $run['items'];
$runId = (int) $run['id'];
?>
<section class="page-head">
  <p class="muted"><a href="index.php?r=selection">← 自动选型系统</a></p>
  <h1>规格书匹配结果</h1>
  <p class="muted">
    <?= e($run['original_name']) ?> · 识别出 <?= count($items) ?> 款灯 · <?= count($run['pages']) ?> 页
    <?php if ($run['seconds'] !== null): ?> · 用时 <?= e((string) $run['seconds']) ?> 秒<?php endif; ?>
    · <?= e((string) $run['created_at']) ?>
  </p>
</section>

<?php if ($run['error'] !== ''): ?>
  <div class="flash flash-error">识别失败：<?= e($run['error']) ?></div>
<?php endif; ?>
<?php foreach ($run['notes'] as $note): ?>
  <div class="flash flash-warn"><?= e((string) $note) ?></div>
<?php endforeach; ?>

<?php if ($run['pages']): ?>
<section class="card">
  <h2>文件页面</h2>
  <div class="page-strip">
    <?php foreach ($run['pages'] as $i => $p): ?>
      <a href="index.php?r=spec_page&amp;id=<?= $runId ?>&amp;p=<?= e($p) ?>" target="_blank" rel="noopener" class="page-thumb">
        <img src="index.php?r=spec_page&amp;id=<?= $runId ?>&amp;p=<?= e($p) ?>" alt="第 <?= $i + 1 ?> 页" loading="lazy">
        <span>第 <?= $i + 1 ?> 页</span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($items): ?>
<form method="post" action="index.php?r=spec_result&amp;id=<?= $runId ?>" id="spec-quote-form">
  <?= Csrf::field() ?>
  <?php foreach ($items as $i => $it):
      $cands = $it['candidates'] ?? [];
      $their = trim(($it['brand'] ?? '') . ' ' . ($it['model'] ?? ''));
      ?>
  <section class="card item-card">
    <div class="item-head">
      <div>
        <h2>第 <?= $i + 1 ?> 款：<?= e($their !== '' ? $their : '（未写型号）') ?><?php if (($it['name'] ?? '') !== ''): ?> <span class="muted-inline"><?= e($it['name']) ?></span><?php endif; ?></h2>
        <p class="muted">
          <?= e($typeLabel((string) $it['type'])) ?><?php if (!empty($it['page'])): ?> · 第 <?= (int) $it['page'] ?> 页<?php endif; ?>
          <?php if (($it['appearance'] ?? '') !== ''): ?> · <?= e($it['appearance']) ?><?php endif; ?>
        </p>
        <div class="chips">
          <?php foreach ($chips($it) as $c): ?><span class="chip"><?= e($c) ?></span><?php endforeach; ?>
        </div>
        <?php if (($it['notes'] ?? '') !== ''): ?><p class="hint">其他要求：<?= e($it['notes']) ?></p><?php endif; ?>
      </div>
      <label class="qty-label">数量
        <input type="number" class="qty" name="qty[<?= (int) $i ?>]" min="1" max="999999" value="<?= (int) ($it['quantity'] ?? 1) ?: 1 ?>">
      </label>
    </div>

    <?php if (!$cands): ?>
      <p class="muted">产品库里没有同类型的产品。</p>
    <?php else: ?>
    <div class="table-scroll">
    <table class="table cand-table">
      <thead>
        <tr><th>选用</th><th>产品</th><th>匹配度</th><th>主要参数</th><th>匹配点 / 差异</th><th class="right">单价（元）</th></tr>
      </thead>
      <tbody>
      <tr>
        <td><input type="radio" name="choice[<?= (int) $i ?>]" value="0" aria-label="这款不报"></td>
        <td colspan="5" class="muted">这款不报</td>
      </tr>
      <?php foreach ($cands as $k => $c):
          $p = $products[(int) $c['product_id']] ?? null;
          if (!$p) { continue; }
          $score = (int) $c['score'];
          ?>
        <tr class="<?= $k === 0 ? 'is-best' : '' ?>">
          <td><input type="radio" name="choice[<?= (int) $i ?>]" value="<?= (int) $p['id'] ?>" <?= $k === 0 ? 'checked' : '' ?> aria-label="选用 <?= e($p['model']) ?>"></td>
          <td class="cand-product">
            <?php if (($p['image_stored_name'] ?? '') !== ''): ?>
              <img class="thumb" src="index.php?r=upload&amp;f=<?= e(urlencode((string) $p['image_stored_name'])) ?>" alt="" loading="lazy">
            <?php else: ?><span class="thumb thumb-empty"></span><?php endif; ?>
            <span><strong><?= e($p['model']) ?></strong><br><span class="muted-inline"><?= e($p['series']) ?> · <?= e($typeLabel((string) $p['type_key'])) ?></span>
              <?php if (!empty($p['catalog_page'])): ?><br><span class="muted-inline">目录 <?= (int) $p['catalog_page'] ?> 页</span><?php endif; ?></span>
          </td>
          <td class="nowrap">
            <div class="score <?= $score >= 80 ? 'score-high' : ($score >= 60 ? 'score-mid' : 'score-low') ?>"><span style="width: <?= max(4, min(100, $score)) ?>%"></span></div>
            <strong><?= $score ?>%</strong>
          </td>
          <td class="cand-params">
            <?= e(implode(' · ', array_filter([
                $p['cut_out'] !== '' ? '开孔 ' . $p['cut_out'] : '',
                $p['dimensions'],
                $p['power'] !== '' ? preg_replace('/\s+\d+V.*$/', '', (string) $p['power']) : '',
                preg_replace('/^\d+K\s*/', '', (string) $p['luminous_flux']),
                (string) $p['adjustability'],
                $p['beam_angle'] !== '' ? '光束 ' . $p['beam_angle'] : '',
                $p['ugr'] !== '' ? 'UGR' . $p['ugr'] : '',
                (string) $p['ip_rating'],
            ]))) ?>
          </td>
          <td class="cand-notes">
            <?php foreach ($c['reasons'] as $r): ?><span class="ok-line">✓ <?= e($r) ?></span><?php endforeach; ?>
            <?php foreach ($c['gaps'] as $g): ?><span class="gap-line">! <?= e($g) ?></span><?php endforeach; ?>
          </td>
          <td class="right nowrap"><?= (float) $p['price'] > 0 ? number_format((float) $p['price'], 2) : '<span class="muted-inline">未定价</span>' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </section>
  <?php endforeach; ?>

  <div class="sticky-actions">
    <button type="submit" class="btn btn-primary">生成报价摘要</button>
    <button type="submit" class="btn btn-secondary" name="format" value="csv">下载报价表（Excel 可打开）</button>
    <span class="muted-inline">每款默认选匹配度最高的型号，可以改选或选“这款不报”。</span>
  </div>
</form>
<?php endif; ?>

<?php if (!empty($quote)): ?>
<section class="card quote-card" id="quote">
  <h2>报价摘要</h2>
  <p class="muted">生成时间：<?= e($quote['created_at']) ?></p>
  <div class="table-scroll">
  <table class="table">
    <thead><tr><th>序号</th><th>客户产品</th><th>我方型号</th><th class="right">单价</th><th class="right">数量</th><th class="right">小计</th><th>需确认</th></tr></thead>
    <tbody>
    <?php foreach ($quote['lines'] as $l): ?>
      <tr>
        <td><?= (int) $l['no'] ?></td>
        <td><?= e($l['their']) ?></td>
        <td><strong><?= e($l['model']) ?></strong><br><span class="muted-inline"><?= e($l['name']) ?> · 匹配度 <?= (int) $l['score'] ?>%</span></td>
        <td class="right"><?= $l['price'] > 0 ? number_format((float) $l['price'], 2) : '未定价' ?></td>
        <td class="right"><?= (int) $l['qty'] ?></td>
        <td class="right"><?= number_format((float) $l['line'], 2) ?></td>
        <td class="cand-notes"><?php foreach ($l['gaps'] as $g): ?><span class="gap-line"><?= e($g) ?></span><?php endforeach; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><td colspan="5" class="right"><strong>合计（元）</strong></td><td class="right"><strong><?= number_format((float) $quote['total'], 2) ?></strong></td><td></td></tr></tfoot>
  </table>
  </div>
  <?php if (array_filter($quote['lines'], static function ($l) { return $l['price'] <= 0; })): ?>
    <p class="hint">有型号还没有定价（单价 0）。在“产品图入库”里补上价格后重新生成即可。</p>
  <?php endif; ?>
</section>
<?php endif; ?>
