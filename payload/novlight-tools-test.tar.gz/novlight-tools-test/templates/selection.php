<?php
/** @var list<array>|null $results */
/** @var string|null $queryPreview */
/** @var array|null $queryMeta */
/** @var array|null $quote */
/** @var string $imageSearchProvider */
/** @var list<array>|null $specRuns */
/** @var bool|null $specReady */

$kindLabels = [
    'image' => '图片',
    'pdf' => 'PDF',
    'excel' => 'Excel',
    'word' => 'Word',
    'zip' => '压缩包',
    'other' => '文件',
];
$imageSearchProvider = $imageSearchProvider ?? 'spec';
$specRuns = $specRuns ?? [];
?>
<section class="page-head">
  <h1>自动选型系统</h1>
  <p class="muted">拖入客户规格书或产品图片 → 识别每款灯的类型和参数 → 在产品库里找最接近的型号 → 勾选生成报价</p>
</section>

<section class="card">
  <h2>上传查询文件</h2>
  <form method="post" action="index.php?r=selection" enctype="multipart/form-data" class="form" id="selection-upload-form">
    <?= Csrf::field() ?>
    <input type="hidden" name="action" value="search">

    <fieldset class="provider-fieldset">
      <legend>识图模块</legend>
      <div class="provider-options" role="radiogroup" aria-label="识图模块">
        <label class="provider-option">
          <input type="radio" name="image_search_provider" value="spec"
            <?= $imageSearchProvider === 'spec' ? 'checked' : '' ?>>
          <span><strong>规格书参数匹配</strong>（推荐，支持多页 PDF）</span>
        </label>
        <label class="provider-option">
          <input type="radio" name="image_search_provider" value="tencent"
            <?= $imageSearchProvider === 'tencent' ? 'checked' : '' ?>>
          <span>腾讯以图搜图（只找几乎一样的图）</span>
        </label>
        <label class="provider-option">
          <input type="radio" name="image_search_provider" value="grok"
            <?= $imageSearchProvider === 'grok' ? 'checked' : '' ?>>
          <span>Grok（海外）</span>
        </label>
      </div>
    </fieldset>

    <div class="dropzone" id="query-dropzone" tabindex="0" role="button" aria-label="拖放或点击选择文件">
      <input
        type="file"
        name="query_file"
        id="query-file-input"
        class="dropzone-input"
        accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.xls,.xlsx,.doc,.docx,.zip,image/jpeg,image/png,image/webp,image/gif,application/pdf,application/zip"
        required
      >
      <div class="dropzone-inner">
        <p class="dropzone-title">将文件拖到此处，或点击选择</p>
        <p class="dropzone-hint">支持：图片（JPEG / PNG / WebP / GIF）、PDF、Excel、Word、ZIP</p>
        <p class="dropzone-hint">单文件最大 50MB</p>
        <p class="dropzone-filename muted" id="query-file-name">尚未选择文件</p>
      </div>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary" id="btn-search" data-busy-text="正在识别，请稍候…">开始识别</button>
    </div>
  </form>
  <p class="hint">
    规格书参数匹配：识图大模型逐页读出每款灯的类型、开孔、尺寸、功率、光通量、调角、光束角、UGR、IP 等，再按参数在产品库里打分，每款给出最接近的几个型号和差异。一份文件最多处理前 20 页，几页的规格书约需 20～60 秒。
    <?php if (empty($specReady)): ?><br><strong class="text-error">识图大模型的接口密钥还没有配置，规格书参数匹配暂时用不了。</strong><?php endif; ?>
  </p>
</section>

<?php if ($specRuns): ?>
<section class="card">
  <h2>最近的规格书识别</h2>
  <table class="table">
    <thead><tr><th>时间</th><th>文件</th><th>识别结果</th><th>用时</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($specRuns as $r): ?>
      <tr>
        <td class="nowrap"><?= e(substr((string) $r['created_at'], 5, 11)) ?></td>
        <td><?= e($r['original_name']) ?></td>
        <td><?= $r['error'] !== '' ? '<span class="text-error">' . e(mb_substr((string) $r['error'], 0, 60)) . '</span>' : (int) $r['item_count'] . ' 款灯' ?></td>
        <td class="nowrap"><?= $r['seconds'] !== null ? e((string) $r['seconds']) . ' 秒' : '' ?></td>
        <td><a href="index.php?r=spec_result&amp;id=<?= (int) $r['id'] ?>">查看</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endif; ?>

<?php if ($queryMeta): ?>
<section class="card">
  <h2>查询文件</h2>
  <?php if (!empty($queryMeta['is_image']) && $queryPreview): ?>
    <img class="preview" src="index.php?r=upload&amp;f=<?= e(urlencode($queryPreview)) ?>" alt="查询图">
  <?php elseif (!empty($queryMeta['preview_image'])): ?>
    <p class="file-chip">
      <span class="file-icon" aria-hidden="true">📦</span>
      <span>
        <strong><?= e($queryMeta['original_name'] ?? '') ?></strong>
        <span class="muted">（<?= e($kindLabels[$queryMeta['kind'] ?? 'other'] ?? '文件') ?>）</span>
      </span>
      <a class="btn btn-primary" href="index.php?r=upload&amp;f=<?= e(urlencode($queryMeta['stored_name'] ?? '')) ?>">下载原文件</a>
    </p>
    <p class="muted">压缩包内预览图：</p>
    <img class="preview" src="index.php?r=upload&amp;f=<?= e(urlencode($queryMeta['preview_image'])) ?>" alt="ZIP 预览图">
  <?php else: ?>
    <p class="file-chip">
      <span class="file-icon" aria-hidden="true">📄</span>
      <span>
        <strong><?= e($queryMeta['original_name'] ?? '') ?></strong>
        <span class="muted">（<?= e($kindLabels[$queryMeta['kind'] ?? 'other'] ?? '文件') ?>）</span>
      </span>
      <?php if (!empty($queryMeta['stored_name'])): ?>
        <a class="btn btn-primary" href="index.php?r=upload&amp;f=<?= e(urlencode($queryMeta['stored_name'])) ?>">下载</a>
      <?php endif; ?>
    </p>
  <?php endif; ?>

  <?php if (!empty($queryMeta['note'])): ?>
    <p class="hint"><?= e($queryMeta['note']) ?></p>
  <?php endif; ?>

  <?php if (!empty($queryMeta['zip_members']) && is_array($queryMeta['zip_members'])): ?>
    <details class="zip-list">
      <summary>压缩包内文件（<?= count($queryMeta['zip_members']) ?> 个）</summary>
      <ul>
        <?php foreach ($queryMeta['zip_members'] as $member): ?>
          <li><code><?= e((string) $member) ?></code></li>
        <?php endforeach; ?>
      </ul>
    </details>
  <?php endif; ?>
</section>
<?php elseif ($queryPreview): ?>
<section class="card">
  <h2>查询图预览</h2>
  <img class="preview" src="index.php?r=upload&amp;f=<?= e(urlencode($queryPreview)) ?>" alt="查询图">
</section>
<?php endif; ?>

<?php if (is_array($results) && $results !== []): ?>
<section class="card">
  <h2>相似产品</h2>
  <p class="muted">来源：<?= e((string) ($results[0]['source'] ?? '')) ?> · 仅展示达到相似度阈值的候选</p>
  <form method="post" action="index.php?r=selection" id="quote-form">
    <?= Csrf::field() ?>
    <input type="hidden" name="action" value="quote">
    <table class="table">
      <thead>
        <tr>
          <th>选择</th>
          <th>名称</th>
          <th>型号</th>
          <th>单价（元）</th>
          <th>相似度</th>
          <th>来源</th>
          <th>数量</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($results as $i => $row): ?>
        <tr>
          <td><input type="checkbox" name="selected[]" value="<?= (int) $i ?>" <?= $i === 0 ? 'checked' : '' ?>></td>
          <td><?= e($row['name']) ?></td>
          <td><code><?= e($row['model']) ?></code></td>
          <td><?= number_format((float) $row['price'], 2) ?></td>
          <td><?= number_format((float) $row['score'] * 100, 1) ?>%</td>
          <td><code><?= e((string) ($row['source'] ?? '')) ?></code></td>
          <td>
            <input type="number" name="qty[<?= (int) $i ?>]" value="1" min="1" max="9999" class="qty">
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <button type="submit" class="btn btn-primary">生成报价摘要</button>
  </form>
</section>
<?php elseif (is_array($results) && $results === [] && $queryMeta): ?>
<section class="card">
  <h2>相似产品</h2>
  <p class="muted">没有达到相似度阈值的候选。请换一张产品正面、背景干净的图再试。</p>
</section>
<?php endif; ?>

<?php if (!empty($quote)): ?>
<section class="card quote-card">
  <h2>报价摘要</h2>
  <p class="muted">生成时间：<?= e($quote['created_at']) ?>（Asia/Shanghai）</p>
  <table class="table">
    <thead>
      <tr>
        <th>名称</th>
        <th>型号</th>
        <th>单价</th>
        <th>数量</th>
        <th>小计</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($quote['items'] as $item): ?>
      <tr>
        <td><?= e($item['name']) ?></td>
        <td><code><?= e($item['model']) ?></code></td>
        <td><?= number_format((float) $item['price'], 2) ?></td>
        <td><?= (int) $item['qty'] ?></td>
        <td><?= number_format((float) $item['line'], 2) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="4" class="right"><strong>合计（元）</strong></td>
        <td><strong><?= number_format((float) $quote['total'], 2) ?></strong></td>
      </tr>
    </tfoot>
  </table>
  <p class="hint">此为页面内摘要，尚未对接导出 PDF / 写入 ERP 报价单。</p>
</section>
<?php endif; ?>
