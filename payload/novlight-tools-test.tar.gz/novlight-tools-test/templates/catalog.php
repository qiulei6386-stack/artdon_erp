<?php
/** @var list<array> $rows */
?>
<section class="page-head">
  <h1>产品图入库</h1>
  <p class="muted">写入独立灯具库（products，与 ERP 分离）。向量/图搜入库 API 尚未接入。</p>
</section>

<section class="card">
  <h2>新增产品</h2>
  <form method="post" action="index.php?r=catalog" enctype="multipart/form-data" class="form">
    <?= Csrf::field() ?>
    <label class="file-label">
      <span>产品图片（JPEG / PNG / WebP / GIF）</span>
      <input type="file" name="product_image" accept="image/jpeg,image/png,image/webp,image/gif" required>
    </label>
    <div class="form-grid">
      <label>
        <span>产品名称</span>
        <input type="text" name="product_name" maxlength="120" required>
      </label>
      <label>
        <span>型号 / SKU</span>
        <input type="text" name="product_model" maxlength="80" required>
      </label>
      <label>
        <span>价格（元）</span>
        <input type="number" name="price" step="0.01" min="0" value="0" required>
      </label>
    </div>
    <div class="form-grid">
      <label>
        <span>品类</span>
        <input type="text" name="category" maxlength="80" placeholder="如：筒灯">
      </label>
      <label>
        <span>品牌</span>
        <input type="text" name="brand" maxlength="80" placeholder="如：Novlight">
      </label>
      <label>
        <span>系列</span>
        <input type="text" name="series" maxlength="80">
      </label>
    </div>
    <label>
      <span>备注</span>
      <textarea name="notes" rows="2" maxlength="500"></textarea>
    </label>
    <button type="submit" class="btn btn-primary">入库</button>
  </form>
  <p class="hint">
    <!-- TODO: ImageSearch::indexImage — 腾讯 CreateImage 或自建向量库 -->
    文件保存在 data/uploads/，元数据写入 SQLite 灯具库 products；相似度特征提取待接入。
  </p>
</section>

<section class="card">
  <h2>灯具库最近记录（最多 50 条）</h2>
  <?php if ($rows === []): ?>
    <p class="muted">暂无记录</p>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>预览</th>
          <th>名称</th>
          <th>型号</th>
          <th>品类</th>
          <th>价格（元）</th>
          <th>来源</th>
          <th>时间</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $row): ?>
        <tr>
          <td>
            <?php if (!empty($row['stored_name'])): ?>
              <img class="thumb" src="index.php?r=upload&amp;f=<?= e(urlencode($row['stored_name'])) ?>" alt="">
            <?php else: ?>
              <span class="muted">—</span>
            <?php endif; ?>
          </td>
          <td><?= e($row['product_name']) ?></td>
          <td><code><?= e($row['product_model']) ?></code></td>
          <td class="muted"><?= e($row['category'] ?? '') ?></td>
          <td><?= number_format((float) ($row['price'] ?? 0), 2) ?></td>
          <td class="muted"><?= e($row['source'] ?? '') ?></td>
          <td><?= e($row['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</section>
