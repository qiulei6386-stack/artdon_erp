<?php
/** @var string $template */
/** @var string $title */
/** @var string $appName */
/** @var array|null $user */
/** @var array|null $flash */
$templateFile = __DIR__ . '/' . $template . '.php';
if (!is_file($templateFile)) {
    http_response_code(500);
    echo '模板缺失';
    exit;
}
?><!DOCTYPE html>
<html lang="zh-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> · <?= e($appName) ?></title>
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
<?php if ($user): ?>
  <header class="topbar">
    <div class="topbar-brand"><?= e($appName) ?></div>
    <nav class="topbar-nav">
      <a href="index.php?r=menu">功能菜单</a>
      <a href="index.php?r=selection">自动选型系统</a>
      <a href="index.php?r=catalog">产品图入库</a>
    </nav>
    <div class="topbar-user">
      <span><?= e($user['display_name']) ?></span>
      <form method="post" action="index.php?r=logout" class="inline">
        <?= Csrf::field() ?>
        <button type="submit" class="link-btn">退出</button>
      </form>
    </div>
  </header>
<?php endif; ?>

<main class="main <?= $user ? 'main-authed' : 'main-guest' ?>">
  <?php if (!empty($flash)): ?>
    <div class="flash flash-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
  <?php endif; ?>
  <?php require $templateFile; ?>
</main>

<script src="assets/js/app.js"></script>
</body>
</html>
