<?php
declare(strict_types=1);

/**
 * 规格书匹配的离线测试（不调用识图接口）。
 *
 *   php tests/run.php [产品库 sqlite 路径]
 *
 * 不给路径时用 data/seed/catalog_2026_2027.json 建一个临时库。
 */

require dirname(__DIR__) . '/src/ProductParams.php';
require dirname(__DIR__) . '/src/SpecExtractor.php';
require dirname(__DIR__) . '/src/SpecMatcher.php';

$fail = 0;
$ok = 0;
function check(bool $cond, string $what): void
{
    global $fail, $ok;
    if ($cond) {
        $ok++;
    } else {
        $fail++;
        fwrite(STDERR, "失败：{$what}\n");
    }
}

// 1) 模型回答解析
$items = SpecExtractor::parse("```json\n" . file_get_contents(__DIR__ . '/fixtures/sail_spec.json') . "\n```");
check(count($items) === 1, '解析出 1 款');
$sail = $items[0];
check($sail['model'] === 'SAIL' && (float) $sail['cutout_mm'] === 45.0, 'SAIL 开孔 45');
check($sail['type'] === 'recessed_downlight' && $sail['adjustable'] === true, 'SAIL 类型/可调');
check(SpecExtractor::parse('没有 JSON') === [], '无 JSON 返回空');
$n = SpecExtractor::normalize(['model' => 'X', 'watt' => '12W', 'cutout_mm' => 'Φ75mm', 'ip' => 'IP44', 'type' => '乱写']);
check((float) $n['watt'] === 12.0 && (float) $n['cutout_mm'] === 75.0 && (float) $n['ip'] === 44.0, '数字从文字里取');
check($n['type'] === 'other', '未知类型归为 other');

// 2) 参数推导
$d = ProductParams::derive(['category' => 'Recessed Spotlight', 'cut_out' => 'Φ45mm', 'dimensions' => 'Φ52×95mm', 'adjustability' => 'Tilt 50°, Rotation 355°', 'ip_rating' => 'IP54', 'ugr' => '<16', 'beam_angle' => '15°/24°/36°']);
check((float) $d['cutout_mm'] === 45.0, 'derive 开孔');
check((int) $d['adjustable'] === 1 && (float) $d['tilt_deg'] === 50.0, 'derive 可调 50°');
check((float) $d['ip_num'] === 54.0 && (float) $d['ugr_max'] === 16.0, 'derive IP/UGR');

// 3) 匹配：SAIL 应首选 LITE 52.04538
$db = $argv[1] ?? '';
if ($db === '') {
    $db = sys_get_temp_dir() . '/nov_test_' . getmypid() . '.sqlite';
    @unlink($db);
    $pdo = new PDO('sqlite:' . $db);
    $pdo->exec('CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, model TEXT, series TEXT, category TEXT, price REAL DEFAULT 0, currency TEXT, image_stored_name TEXT, catalog_page INTEGER,
        cut_out TEXT, dimensions TEXT, power TEXT, power_watts REAL, luminous_flux TEXT, adjustability TEXT, adaptor TEXT, beam_angle TEXT, cct TEXT, cri TEXT, ugr TEXT, dimming_method TEXT, ip_rating TEXT, best_for TEXT)');
    $ins = $pdo->prepare('INSERT INTO products (name, model, series, category, catalog_page, cut_out, dimensions, power, power_watts, luminous_flux, adjustability, adaptor, beam_angle, cct, cri, ugr, dimming_method, ip_rating, best_for)
        VALUES (:name, :model, :series, :category, :catalog_page, :cut_out, :dimensions, :power, :pw, :luminous_flux, :adjustability, :adaptor, :beam_angle, :cct, :cri, :ugr, :dimming_method, :ip_rating, :best_for)');
    foreach (json_decode((string) file_get_contents(dirname(__DIR__) . '/data/seed/catalog_2026_2027.json'), true) as $s) {
        $row = [];
        foreach (['name', 'model', 'series', 'category', 'catalog_page', 'cut_out', 'dimensions', 'power', 'luminous_flux', 'adjustability', 'adaptor', 'beam_angle', 'cct', 'cri', 'ugr', 'dimming_method', 'ip_rating', 'best_for'] as $c) {
            $row[':' . $c] = $s[$c] ?? '';
        }
        $row[':name'] = $row[':name'] !== '' ? $row[':name'] : $s['model'];
        $row[':category'] = ucwords(strtolower((string) ($s['category_en'] ?? '')));
        $row[':catalog_page'] = (int) ($s['catalog_page_printed'] ?? 0);
        $row[':pw'] = preg_match('/(\d+(?:\.\d+)?)\s*W/i', (string) ($s['power'] ?? ''), $m) ? (float) $m[1] : null;
        $ins->execute($row);
    }
    ProductParams::migrate($pdo);
    $tmp = $db;
} else {
    $pdo = new PDO('sqlite:' . $db);
}
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// 规格书写的是 "Recessed Adjustable downlight"，模型可能归为筒灯也可能归为射灯，两种都要选对
foreach (['recessed_downlight', 'recessed_spotlight'] as $asType) {
    $cands = (new SpecMatcher($pdo))->match(['type' => $asType] + $sail, 5);
    check($cands !== [], '有候选');
    $top = $cands[0]['product']['model'] ?? '';
    check($top === '52.04538', "按{$asType}：SAIL 首选 LITE 52.04538（实际：{$top}）");
    fwrite(STDOUT, "按 {$asType}：\n");
    foreach ($cands as $c) {
        fwrite(STDOUT, sprintf("  %-10s %-10s %3d%%  差异：%s\n", $c['product']['model'], $c['product']['series'], $c['score'], implode('；', $c['gaps']) ?: '无'));
        check(ProductParams::GROUPS[$c['product']['type_key']] === 'recessed', '候选都是嵌入式：' . $c['product']['model']);
    }
}
if (isset($tmp)) {
    $pdo = null;
    @unlink($tmp);
}

fwrite(STDOUT, "通过 {$ok} 项，失败 {$fail} 项\n");
exit($fail ? 1 : 0);
