<?php
/**
 * 站点配置。部署到服务器后可按需覆盖密钥、数据库路径等。
 */
declare(strict_types=1);

return [
    'app_name' => 'Novlight 工具台',
    'timezone' => 'Asia/Shanghai',

    // SQLite 数据库文件（相对项目根目录）
    'db_path' => __DIR__ . '/data/app.sqlite',

    // 上传目录（相对项目根）
    'upload_dir' => __DIR__ . '/data/uploads',
    'upload_max_bytes' => 50 * 1024 * 1024, // 50MB

    // 产品图入库：仅图片
    'upload_allowed_mime' => ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
    'upload_allowed_ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif'],

    // 自动选型查询：图片 + PDF / Office / ZIP
    'query_allowed_mime' => [
        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
        'application/pdf',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip',
        'application/x-zip-compressed',
        'application/octet-stream', // 部分浏览器对 doc/xls/zip 报此 MIME，再靠扩展名校验
    ],
    'query_allowed_ext' => [
        'jpg', 'jpeg', 'png', 'webp', 'gif',
        'pdf',
        'xls', 'xlsx',
        'doc', 'docx',
        'zip',
    ],

    // Session
    'session_name' => 'novlight_tools_sess',

    // 种子管理员（仅当 users 表为空时写入；密码用 password_hash）
    'seed_admin' => [
        'username' => 'admin',
        'password' => '请在服务器上设置',
        'display_name' => '管理员',
    ],

    // 图像相似度：tencent | grok | openai | mock
    'image_search_provider' => 'tencent',

    // 生产环境密钥文件（返回数组含 secret_id / secret_key / region）；勿提交真实密钥
    'tencent_secrets_file' => '/www/server/artdon_secrets/tencent_ocr.php',

    'image_search' => [
        // 正式腾讯检索：禁止回退 mock（否则空结果/报错会变成 3 条样例垃圾）
        'fallback_mock' => false,
        // 腾讯 MatchThreshold（0–100）；低于此分的候选不返回
        'match_threshold' => 60,
        'tencent' => [
            // 本地可直接填；生产优先留空，由 tencent_secrets_file 注入
            'secret_id' => '',
            'secret_key' => '',
            'region' => 'ap-guangzhou',
            'group_id' => 'novlight_lighting',
            'group_type' => 4, // 4=通用图像搜索
            'max_capacity' => 10000,
        ],
        'openai' => [
            'api_key' => '',
        ],
    ],

    // 规格书参数匹配（识图大模型读规格书 → 按参数找自家产品）
    'spec' => [
        // qwen = 阿里云百炼通义千问 VL（默认 qwen-vl-max）
        // hunyuan = 腾讯混元视觉（默认 hunyuan-vision）
        // fixture = 离线测试（读 tests/fixtures/<文件名>.json，不调用接口）
        'provider' => 'qwen',
        // 密钥放服务器文件里（返回 ['api_key' => '...']），不要写进代码库。
        // 不写时默认：qwen → /www/server/artdon_secrets/dashscope.php，hunyuan → /www/server/artdon_secrets/hunyuan.php
        // 'secrets_file' => '',
        // 'model' => '',   // 不写用默认模型
        'pages_per_request' => 4,   // 每次发给模型几页
        'max_pages' => 20,          // 一份文件最多处理几页
        'timeout' => 150,           // 单次请求超时（秒）
        'candidates' => 5,          // 每款灯列几个候选
    ],
];
