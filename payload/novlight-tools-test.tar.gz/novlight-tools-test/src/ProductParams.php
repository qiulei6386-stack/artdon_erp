<?php
declare(strict_types=1);

/**
 * 灯具参数：把产品表里的文字参数（如 "45mm"、"10W 36V 250mA"、"Tilt 30° Rotation 350°"）
 * 拆成可比较的数字列，供规格书匹配用。
 */
final class ProductParams
{
    /** 灯具类型（匹配时先按类型缩小范围）。 */
    public const TYPES = [
        'recessed_downlight' => '嵌入式筒灯',
        'recessed_spotlight' => '嵌入式射灯',
        'wall_washer_recessed' => '嵌入式洗墙灯',
        'cabinet_light' => '柜灯',
        'track_light' => '导轨灯',
        'magnetic_track_light' => '磁吸轨道灯',
        'magnetic_linear_light' => '磁吸线条灯',
        'surface_light' => '明装灯',
        'pendant' => '吊灯',
        'other' => '其他',
    ];

    /** 同组类型可以互相替代（分数打折）。 */
    public const GROUPS = [
        'recessed_downlight' => 'recessed',
        'recessed_spotlight' => 'recessed',
        'wall_washer_recessed' => 'recessed',
        'cabinet_light' => 'cabinet',
        'track_light' => 'track',
        'magnetic_track_light' => 'track',
        'magnetic_linear_light' => 'linear',
        'surface_light' => 'surface',
        'pendant' => 'pendant',
        'other' => 'other',
    ];

    /** 新增的数字列：列名 => 定义。 */
    public const NUMERIC_COLUMNS = [
        'type_key' => "TEXT NOT NULL DEFAULT ''",
        'cutout_mm' => 'REAL',
        'diameter_mm' => 'REAL',
        'height_mm' => 'REAL',
        'lumen' => 'REAL',
        'adjustable' => 'INTEGER NOT NULL DEFAULT 0',
        'tilt_deg' => 'REAL',
        'rotation_deg' => 'REAL',
        'beam_min' => 'REAL',
        'beam_max' => 'REAL',
        'cct_min' => 'REAL',
        'cct_max' => 'REAL',
        'cri_num' => 'REAL',
        'ugr_max' => 'REAL',
        'ip_num' => 'REAL',
        'wall_wash' => 'INTEGER NOT NULL DEFAULT 0',
        'is_active' => 'INTEGER NOT NULL DEFAULT 1',
    ];

    /** 由品类文字猜类型。 */
    public static function typeFromCategory(string $category, string $series = '', string $adaptor = ''): string
    {
        $c = strtolower($category);
        // 手工入库时常写中文品类
        foreach (['柜' => 'cabinet_light', '磁吸线' => 'magnetic_linear_light', '线条' => 'magnetic_linear_light', '线性' => 'magnetic_linear_light',
            '磁吸' => 'magnetic_track_light', '轨道' => 'track_light', '洗墙' => 'wall_washer_recessed', '射灯' => 'recessed_spotlight',
            '筒灯' => 'recessed_downlight', '明装' => 'surface_light', '吸顶' => 'surface_light', '吊灯' => 'pendant'] as $zh => $type) {
            if (strpos($category, $zh) !== false) {
                return $type;
            }
        }
        if (strpos($c, 'cabinet') !== false) {
            return 'cabinet_light';
        }
        if (strpos($c, 'linear') !== false) {
            return 'magnetic_linear_light';
        }
        if (strpos($c, 'low voltage') !== false || strpos($c, 'magnetic') !== false || stripos($adaptor, '48V') !== false) {
            return 'magnetic_track_light';
        }
        if (strpos($c, 'track') !== false) {
            return 'track_light';
        }
        if (strpos($c, 'wall-wash') !== false || strpos($c, 'wall wash') !== false) {
            return strpos($c, 'recess') !== false || strpos($c, 'downlight') !== false ? 'wall_washer_recessed' : 'surface_light';
        }
        if (strpos($c, 'recessed spotlight') !== false) {
            return 'recessed_spotlight';
        }
        if (strpos($c, 'recessed') !== false || strpos($c, 'downlight') !== false) {
            return 'recessed_downlight';
        }
        if (strpos($c, 'surface') !== false) {
            return 'surface_light';
        }
        if (strpos($c, 'pendant') !== false || strpos($c, 'suspension') !== false) {
            return 'pendant';
        }
        return 'other';
    }

    /**
     * 从一行产品的文字列算出数字列。
     *
     * @param array<string, mixed> $p
     * @return array<string, mixed>
     */
    public static function derive(array $p): array
    {
        $dims = self::numbers((string) ($p['dimensions'] ?? ''));
        $beams = self::numbers((string) ($p['beam_angle'] ?? ''));
        $ccts = array_values(array_filter(self::numbers((string) ($p['cct'] ?? '')), static function ($v) {
            return $v >= 1000;
        }));
        $adj = (string) ($p['adjustability'] ?? '');
        $tilt = self::first('/Tilt\s*(\d+(?:\.\d+)?)/i', $adj);
        $rot = self::first('/Rotation\s*(\d+(?:\.\d+)?)/i', $adj);
        $ugr = self::first('/<\s*(\d+(?:\.\d+)?)/', (string) ($p['ugr'] ?? ''));
        $lumen = self::first('/(\d+(?:\.\d+)?)\s*lm/i', (string) ($p['luminous_flux'] ?? ''));
        $series = strtoupper((string) ($p['series'] ?? ''));
        $washer = strpos($series, 'WASH') !== false || stripos((string) ($p['beam_angle'] ?? ''), 'wall') !== false
            || stripos((string) ($p['category'] ?? ''), 'wall') !== false;
        return [
            'type_key' => self::typeFromCategory((string) ($p['category'] ?? ''), $series, (string) ($p['adaptor'] ?? '')),
            'cutout_mm' => self::first('/(\d+(?:\.\d+)?)\s*mm/i', (string) ($p['cut_out'] ?? '')),
            'diameter_mm' => $dims[0] ?? null,
            'height_mm' => $dims[1] ?? null,
            'lumen' => $lumen,
            'adjustable' => ($tilt !== null && $tilt > 0) || stripos($adj, 'arm') !== false ? 1 : 0,
            'tilt_deg' => $tilt !== null && $tilt > 0 ? $tilt : null,
            'rotation_deg' => $rot,
            'beam_min' => $beams ? min($beams) : null,
            'beam_max' => $beams ? max($beams) : null,
            'cct_min' => $ccts ? min($ccts) : null,
            'cct_max' => $ccts ? max($ccts) : null,
            'cri_num' => self::first('/(\d+)/', (string) ($p['cri'] ?? '')),
            'ugr_max' => $ugr !== null && $ugr > 0 ? $ugr : null,
            'ip_num' => self::first('/IP\s*(\d\d)/i', (string) ($p['ip_rating'] ?? '')),
            'wall_wash' => $washer ? 1 : 0,
        ];
    }

    /** 补齐表结构。 */
    public static function migrate(PDO $pdo): void
    {
        $cols = [];
        foreach ($pdo->query('PRAGMA table_info(products)') as $row) {
            $cols[$row['name']] = true;
        }
        $added = false;
        foreach (self::NUMERIC_COLUMNS as $name => $decl) {
            if (!isset($cols[$name])) {
                $pdo->exec("ALTER TABLE products ADD COLUMN {$name} {$decl}");
                $added = true;
            }
        }
        if ($added) {
            self::refreshAll($pdo);
        }
    }

    /** 按文字列重新计算所有产品的数字列。 */
    public static function refreshAll(PDO $pdo): int
    {
        $rows = $pdo->query('SELECT * FROM products')->fetchAll(PDO::FETCH_ASSOC);
        $n = 0;
        foreach ($rows as $row) {
            self::save($pdo, (int) $row['id'], self::derive($row));
            $n++;
        }
        return $n;
    }

    /** @param array<string, mixed> $values */
    public static function save(PDO $pdo, int $id, array $values): void
    {
        $sets = [];
        $params = [':id' => $id];
        foreach ($values as $k => $v) {
            if (!isset(self::NUMERIC_COLUMNS[$k])) {
                continue;
            }
            $sets[] = $k . ' = :' . $k;
            $params[':' . $k] = $v;
        }
        if ($sets) {
            $pdo->prepare('UPDATE products SET ' . implode(', ', $sets) . ' WHERE id = :id')->execute($params);
        }
    }

    /** @return list<float> */
    public static function numbers(string $s): array
    {
        preg_match_all('/\d+(?:\.\d+)?/', $s, $m);
        return array_map('floatval', $m[0]);
    }

    private static function first(string $re, string $s): ?float
    {
        return preg_match($re, $s, $m) ? (float) $m[1] : null;
    }
}
