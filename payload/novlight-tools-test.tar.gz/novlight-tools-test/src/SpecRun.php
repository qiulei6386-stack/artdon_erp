<?php
declare(strict_types=1);

/**
 * 一次规格书识别：保存上传文件 → 转页面图片 → 识图模型读参数 → 每款灯按参数匹配候选 → 存记录。
 * 记录在 spec_runs 表，页面图片在 upload_dir/spec/{编号}/。
 */
final class SpecRun
{
    public static function dir(array $config, int $id): string
    {
        return rtrim((string) $config['upload_dir'], '/') . '/spec/' . $id;
    }

    /** 处理上传，返回记录编号。出错时记录里留下错误原因再抛出。 */
    public static function process(PDO $pdo, array $config, array $file, int $userId, ?SpecExtractor $extractor = null): int
    {
        $extractor = $extractor ?? new SpecExtractor($config);
        $saved = Upload::saveQueryFile($file, $config);
        $pdo->prepare('INSERT INTO spec_runs (user_id, original_name, stored_name, kind, extractor) VALUES (?, ?, ?, ?, ?)')
            ->execute([$userId, $saved['original_name'], $saved['stored_name'], $saved['kind'], $extractor->provider()]);
        $id = (int) $pdo->lastInsertId();
        $started = microtime(true);
        try {
            $doc = new SpecDocument(self::dir($config, $id), $extractor->maxPages());
            $src = rtrim((string) $config['upload_dir'], '/') . '/' . $saved['stored_name'];
            $prepared = $doc->process($src, $saved['original_name']);
            $pdo->prepare('UPDATE spec_runs SET pages_json = ? WHERE id = ?')
                ->execute([json_encode($prepared['pages']), $id]);
            $paths = array_map(static function (string $p) use ($config, $id): string {
                return self::dir($config, $id) . '/' . $p;
            }, $prepared['pages']);
            $items = $extractor->extract($paths, $prepared['text'], $saved['original_name']);
            if (!$items) {
                throw new RuntimeException('没有从文件里识别出灯具。请确认文件是灯具规格书或清晰的产品图片');
            }
            $matcher = new SpecMatcher($pdo);
            $limit = max(1, (int) ($config['spec']['candidates'] ?? 5));
            foreach ($items as &$item) {
                $item['candidates'] = array_map(static function (array $c): array {
                    return [
                        'product_id' => (int) $c['product']['id'],
                        'score' => $c['score'],
                        'reasons' => $c['reasons'],
                        'gaps' => $c['gaps'],
                    ];
                }, $matcher->match($item, $limit));
            }
            unset($item);
            $pdo->prepare('UPDATE spec_runs SET items_json = ?, seconds = ?, error = ? WHERE id = ?')->execute([
                json_encode(['items' => $items, 'notes' => $prepared['notes']], JSON_UNESCAPED_UNICODE),
                round(microtime(true) - $started, 1),
                '',
                $id,
            ]);
        } catch (Throwable $e) {
            $pdo->prepare('UPDATE spec_runs SET error = ?, seconds = ? WHERE id = ?')
                ->execute([mb_substr($e->getMessage(), 0, 1000, 'UTF-8'), round(microtime(true) - $started, 1), $id]);
            throw $e;
        }
        return $id;
    }

    /** @return array<string, mixed>|null */
    public static function find(PDO $pdo, int $id, int $userId): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM spec_runs WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $userId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }
        $data = json_decode((string) $row['items_json'], true);
        $row['items'] = is_array($data) && isset($data['items']) ? $data['items'] : [];
        $row['notes'] = is_array($data) && isset($data['notes']) ? $data['notes'] : [];
        $row['pages'] = json_decode((string) $row['pages_json'], true) ?: [];
        return $row;
    }

    /** @return list<array<string, mixed>> */
    public static function recent(PDO $pdo, int $userId, int $limit): array
    {
        $stmt = $pdo->prepare('SELECT id, original_name, kind, items_json, error, seconds, created_at FROM spec_runs WHERE user_id = ? ORDER BY id DESC LIMIT ' . (int) $limit);
        $stmt->execute([$userId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$r) {
            $d = json_decode((string) $r['items_json'], true);
            $r['item_count'] = is_array($d) && isset($d['items']) ? count($d['items']) : 0;
            unset($r['items_json']);
        }
        unset($r);
        return $rows;
    }

    /** 记录里用到的产品（按编号）。 @return array<int, array<string, mixed>> */
    public static function productsFor(PDO $pdo, array $run): array
    {
        $ids = [];
        foreach ($run['items'] as $it) {
            foreach ($it['candidates'] ?? [] as $c) {
                $ids[(int) $c['product_id']] = true;
            }
        }
        if (!$ids) {
            return [];
        }
        $in = implode(',', array_map('intval', array_keys($ids)));
        $out = [];
        foreach ($pdo->query("SELECT * FROM products WHERE id IN ({$in})") as $p) {
            $out[(int) $p['id']] = $p;
        }
        return $out;
    }

    /**
     * 生成报价：每款灯选一个型号和数量。
     *
     * @param array<mixed> $choice 款号 => 产品编号
     * @param array<mixed> $qty 款号 => 数量
     * @return array{lines: list<array<string, mixed>>, total: float, currency: string, created_at: string}
     */
    public static function quote(PDO $pdo, array $run, array $choice, array $qty): array
    {
        $products = self::productsFor($pdo, $run);
        $lines = [];
        $total = 0.0;
        foreach ($run['items'] as $i => $it) {
            $pid = (int) ($choice[$i] ?? 0);
            if ($pid <= 0 || !isset($products[$pid])) {
                continue;
            }
            $allowed = array_map(static function ($c) {
                return (int) $c['product_id'];
            }, $it['candidates'] ?? []);
            if (!in_array($pid, $allowed, true)) {
                continue;
            }
            $cand = null;
            foreach ($it['candidates'] as $c) {
                if ((int) $c['product_id'] === $pid) {
                    $cand = $c;
                }
            }
            $p = $products[$pid];
            $q = max(1, min(999999, (int) ($qty[$i] ?? ($it['quantity'] ?? 1))));
            $price = (float) $p['price'];
            $total += $price * $q;
            $lines[] = [
                'no' => $i + 1,
                'their' => trim(($it['brand'] ?? '') . ' ' . ($it['model'] ?? '') . ' ' . ($it['name'] ?? '')),
                'model' => (string) $p['model'],
                'name' => (string) $p['name'],
                'price' => $price,
                'qty' => $q,
                'line' => $price * $q,
                'score' => (int) ($cand['score'] ?? 0),
                'gaps' => (array) ($cand['gaps'] ?? []),
            ];
        }
        return ['lines' => $lines, 'total' => $total, 'currency' => 'CNY', 'created_at' => date('Y-m-d H:i:s')];
    }

    public static function sendCsv(array $quote, array $run): void
    {
        $name = '报价_' . preg_replace('/[^\w\x{4e00}-\x{9fa5}.-]+/u', '_', pathinfo((string) $run['original_name'], PATHINFO_FILENAME)) . '_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"quote.csv\"; filename*=UTF-8''" . rawurlencode($name));
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['序号', '客户规格书产品', '我方型号', '我方名称', '单价（元）', '数量', '小计（元）', '匹配度', '需确认']);
        foreach ($quote['lines'] as $l) {
            fputcsv($out, array_map([self::class, 'csvCell'], [$l['no'], $l['their'], $l['model'], $l['name'], number_format($l['price'], 2, '.', ''), $l['qty'], number_format($l['line'], 2, '.', ''), $l['score'] . '%', implode('；', $l['gaps'])]));
        }
        fputcsv($out, ['', '', '', '', '', '合计', number_format($quote['total'], 2, '.', ''), '', '']);
        fclose($out);
    }

    /** 防止表格公式注入。 @param mixed $v */
    public static function csvCell($v): string
    {
        $s = (string) $v;
        return $s !== '' && strpos('=+-@', $s[0]) !== false && !is_numeric($s) ? "'" . $s : $s;
    }
}
