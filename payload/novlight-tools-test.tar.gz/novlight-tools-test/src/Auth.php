<?php
declare(strict_types=1);

final class Auth
{
    private const USER_KEY = 'user_id';

    public static function startSession(array $config): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        if (PHP_SAPI === 'cli') {
            // 冒烟/CLI：避免 headers already sent 警告
            if (!headers_sent()) {
                session_name($config['session_name'] ?? 'novlight_tools_sess');
            }
            @session_start();
            return;
        }
        session_name($config['session_name'] ?? 'novlight_tools_sess');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            // 生产 HTTPS 时可改为 true；本地 php -S 保持 false
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        ]);
        session_start();
    }

    public static function attempt(PDO $pdo, string $username, string $password): bool
    {
        $stmt = $pdo->prepare('SELECT id, username, password_hash, display_name FROM users WHERE username = :u LIMIT 1');
        $stmt->execute([':u' => $username]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            return false;
        }
        session_regenerate_id(true);
        $_SESSION[self::USER_KEY] = (int) $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['display_name'] = $row['display_name'] ?: $row['username'];
        return true;
    }

    public static function check(): bool
    {
        return !empty($_SESSION[self::USER_KEY]);
    }

    public static function id(): ?int
    {
        return isset($_SESSION[self::USER_KEY]) ? (int) $_SESSION[self::USER_KEY] : null;
    }

    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }
        return [
            'id' => self::id(),
            'username' => $_SESSION['username'] ?? '',
            'display_name' => $_SESSION['display_name'] ?? '',
        ];
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            header('Location: index.php?r=login');
            exit;
        }
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool) $p['secure'], (bool) $p['httponly']);
        }
        session_destroy();
    }
}
