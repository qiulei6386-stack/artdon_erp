<?php
declare(strict_types=1);

/**
 * 腾讯云 TIAA（图像识别 / 图像搜索）纯 PHP 客户端。
 * 使用 TC3-HMAC-SHA256，无 Composer 依赖。
 *
 * API: https://tiia.tencentcloudapi.com  Version 2019-05-29
 */
final class TencentTiiaClient
{
    private const HOST = 'tiia.tencentcloudapi.com';
    private const SERVICE = 'tiia';
    private const VERSION = '2019-05-29';
    private const ENDPOINT = 'https://tiia.tencentcloudapi.com';

    private string $secretId;
    private string $secretKey;
    private string $region;
    private string $groupId;
    private int $groupType;
    private int $maxCapacity;
    private bool $groupEnsured = false;

    public function __construct(array $tencentConfig)
    {
        $this->secretId = (string) ($tencentConfig['secret_id'] ?? '');
        $this->secretKey = (string) ($tencentConfig['secret_key'] ?? '');
        $this->region = (string) ($tencentConfig['region'] ?? 'ap-guangzhou');
        $this->groupId = (string) ($tencentConfig['group_id'] ?? 'novlight_lighting');
        $this->groupType = (int) ($tencentConfig['group_type'] ?? 4);
        $this->maxCapacity = (int) ($tencentConfig['max_capacity'] ?? 10000);

        if ($this->secretId === '' || $this->secretKey === '') {
            throw new RuntimeException('腾讯云密钥未配置（secret_id / secret_key 为空）');
        }
        if ($this->groupId === '') {
            throw new RuntimeException('腾讯云图库 group_id 未配置');
        }
    }

    public function getGroupId(): string
    {
        return $this->groupId;
    }

    /**
     * 确保图库存在；已存在则忽略。
     * GroupType=4 通用图像搜索。
     */
    public function createGroupIfNeeded(): void
    {
        if ($this->groupEnsured) {
            return;
        }

        try {
            $this->request('CreateGroup', [
                'GroupId' => $this->groupId,
                'GroupName' => $this->groupId,
                'MaxCapacity' => max(100, $this->maxCapacity),
                'Brief' => 'Novlight 灯具选型图库',
                'GroupType' => $this->groupType,
            ]);
        } catch (RuntimeException $ex) {
            $msg = $ex->getMessage();
            // 图库已存在等可忽略
            if (
                stripos($msg, 'Already') !== false
                || stripos($msg, 'exist') !== false
                || stripos($msg, '已存在') !== false
                || stripos($msg, 'ResourceInUse') !== false
                || stripos($msg, 'InvalidParameterValue.GroupIdAlreadyExist') !== false
                || stripos($msg, 'GroupIdAlreadyExist') !== false
                || stripos($msg, 'FailedOperation.ImageGroupExist') !== false
            ) {
                // ok
            } else {
                throw $ex;
            }
        }

        $this->groupEnsured = true;
    }

    /**
     * 创建/追加图片到图库。
     *
     * @param string $entityId 物品 ID，如 p12
     * @param string $picName  图片名，如 p12_main
     * @param string|null $imageBase64 纯 base64（无 data: 前缀）；与 $filePath 二选一
     * @param string|null $filePath 本地图片路径
     * @param string $customContent 自定义文本（建议 JSON）
     */
    public function createImage(
        string $entityId,
        string $picName,
        ?string $imageBase64 = null,
        ?string $filePath = null,
        string $customContent = '',
    ): array {
        $this->createGroupIfNeeded();

        if ($imageBase64 === null || $imageBase64 === '') {
            if ($filePath === null || $filePath === '' || !is_readable($filePath)) {
                throw new RuntimeException('CreateImage 需要可读的图片文件或 ImageBase64');
            }
            $raw = file_get_contents($filePath);
            if ($raw === false || $raw === '') {
                throw new RuntimeException('无法读取图片文件: ' . $filePath);
            }
            $imageBase64 = base64_encode($raw);
        }

        $body = [
            'GroupId' => $this->groupId,
            'EntityId' => $entityId,
            'PicName' => $picName,
            'ImageBase64' => $imageBase64,
        ];
        if ($customContent !== '') {
            $body['CustomContent'] = substr($customContent, 0, 4096);
        }

        return $this->request('CreateImage', $body);
    }

    /**
     * 删除图库中的图片。
     * PicName 为空时删除该 EntityId 下全部图片。
     */
    public function deleteImages(string $entityId, ?string $picName = null): array
    {
        $body = [
            'GroupId' => $this->groupId,
            'EntityId' => $entityId,
        ];
        if ($picName !== null && $picName !== '') {
            $body['PicName'] = $picName;
        }
        return $this->request('DeleteImages', $body);
    }

    /**
     * 以图搜图。
     *
     * @return array{ImageInfos?: list<array>, ...}
     */
    public function searchImage(
        string $imageBase64OrPath,
        int $limit = 10,
        int $matchThreshold = 0,
        bool $isFilePath = false,
    ): array {
        if ($isFilePath) {
            if (!is_readable($imageBase64OrPath)) {
                throw new RuntimeException('检索图不可读: ' . $imageBase64OrPath);
            }
            $raw = file_get_contents($imageBase64OrPath);
            if ($raw === false || $raw === '') {
                throw new RuntimeException('无法读取检索图');
            }
            $b64 = base64_encode($raw);
        } else {
            $b64 = $imageBase64OrPath;
        }

        // 注意：腾讯对 MatchThreshold=0 在低分场景常直接返回空 ImageInfos；
        // 需要“尽量全量候选”时请传 1，再在业务侧按阈值过滤。
        $apiThreshold = max(0, min(100, $matchThreshold));
        if ($apiThreshold === 0) {
            $apiThreshold = 1;
        }
        return $this->request('SearchImage', [
            'GroupId' => $this->groupId,
            'ImageBase64' => $b64,
            'Limit' => max(1, min(100, $limit)),
            'MatchThreshold' => $apiThreshold,
            'Offset' => 0,
        ]);
    }

    /** 可选：列出图库 */
    public function describeGroups(int $offset = 0, int $limit = 30): array
    {
        return $this->request('DescribeGroups', [
            'Offset' => $offset,
            'Limit' => $limit,
        ]);
    }

    /**
     * 构建 Authorization 头（供单测校验格式，不发请求）。
     *
     * @return array{authorization:string, timestamp:int, payload:string, headers:array<string,string>}
     */
    public function buildSignedRequest(string $action, array $params, ?int $timestamp = null): array
    {
        $timestamp = $timestamp ?? time();
        $payload = $params === [] ? '{}' : (json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}');
        $authorization = $this->sign($action, $payload, $timestamp);

        $headers = [
            'Content-Type' => 'application/json; charset=utf-8',
            'Host' => self::HOST,
            'X-TC-Action' => $action,
            'X-TC-Timestamp' => (string) $timestamp,
            'X-TC-Version' => self::VERSION,
            'X-TC-Region' => $this->region,
            'Authorization' => $authorization,
        ];

        return [
            'authorization' => $authorization,
            'timestamp' => $timestamp,
            'payload' => $payload,
            'headers' => $headers,
        ];
    }

    /**
     * @return array Response 业务体（已去掉外层 Response 包装时的内层，或整包）
     */
    public function request(string $action, array $params): array
    {
        $signed = $this->buildSignedRequest($action, $params);
        $headers = [];
        foreach ($signed['headers'] as $k => $v) {
            $headers[] = $k . ': ' . $v;
        }

        $ch = curl_init(self::ENDPOINT);
        if ($ch === false) {
            throw new RuntimeException('无法初始化 HTTP 客户端');
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $signed['payload'],
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 15,
        ]);
        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $err = curl_error($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno !== 0 || $raw === false) {
            throw new RuntimeException('腾讯云 API 网络错误: ' . ($err !== '' ? $err : 'curl ' . $errno));
        }

        $json = json_decode($raw, true);
        if (!is_array($json)) {
            throw new RuntimeException('腾讯云 API 返回非 JSON（HTTP ' . $httpCode . '）');
        }

        $resp = $json['Response'] ?? $json;
        if (!is_array($resp)) {
            throw new RuntimeException('腾讯云 API 响应格式异常');
        }

        if (isset($resp['Error']) && is_array($resp['Error'])) {
            $code = (string) ($resp['Error']['Code'] ?? 'Unknown');
            $message = (string) ($resp['Error']['Message'] ?? '');
            throw new RuntimeException(
                $this->friendlyError($code, $message),
                0
            );
        }

        return $resp;
    }

    private function friendlyError(string $code, string $message): string
    {
        $map = [
            'FailedOperation.UnOpenError' => '腾讯云图像搜索未开通，请在控制台开通「图像搜索」后再试',
            'AuthFailure.SecretIdNotFound' => '腾讯云 SecretId 无效',
            'AuthFailure.SignatureFailure' => '腾讯云签名校验失败，请检查 SecretKey',
            'AuthFailure.UnauthorizedOperation' => '当前密钥无权调用图像搜索 API',
            'ResourceUnavailable' => '腾讯云图像搜索资源不可用，请确认已开通服务',
            'InvalidParameterValue.NoImageInGroup' => '图库为空，请先在「产品图入库」写入带图产品',
            'InvalidParameter.ImageEmpty' => '图片内容为空或无法解析',
            'LimitExceeded' => '腾讯云调用超限，请稍后重试或升级配额',
        ];
        foreach ($map as $needle => $zh) {
            if (stripos($code, $needle) !== false || $code === $needle) {
                return $zh . '（' . $code . '）';
            }
        }
        if ($message !== '') {
            return '腾讯云图像搜索失败: ' . $code . ' — ' . $message;
        }
        return '腾讯云图像搜索失败: ' . $code;
    }

    /**
     * TC3-HMAC-SHA256 签名，返回完整 Authorization 头值。
     */
    public function sign(string $action, string $payload, int $timestamp): string
    {
        $algorithm = 'TC3-HMAC-SHA256';
        $date = gmdate('Y-m-d', $timestamp);
        $credentialScope = $date . '/' . self::SERVICE . '/tc3_request';

        $hashedPayload = hash('sha256', $payload);
        $canonicalHeaders =
            "content-type:application/json; charset=utf-8\n" .
            'host:' . self::HOST . "\n";
        $signedHeaders = 'content-type;host';

        $canonicalRequest =
            "POST\n" .
            "/\n" .
            "\n" .
            $canonicalHeaders . "\n" .
            $signedHeaders . "\n" .
            $hashedPayload;

        $stringToSign =
            $algorithm . "\n" .
            $timestamp . "\n" .
            $credentialScope . "\n" .
            hash('sha256', $canonicalRequest);

        $secretDate = hash_hmac('sha256', $date, 'TC3' . $this->secretKey, true);
        $secretService = hash_hmac('sha256', self::SERVICE, $secretDate, true);
        $secretSigning = hash_hmac('sha256', 'tc3_request', $secretService, true);
        $signature = hash_hmac('sha256', $stringToSign, $secretSigning);

        return $algorithm
            . ' Credential=' . $this->secretId . '/' . $credentialScope
            . ', SignedHeaders=' . $signedHeaders
            . ', Signature=' . $signature;
    }
}
