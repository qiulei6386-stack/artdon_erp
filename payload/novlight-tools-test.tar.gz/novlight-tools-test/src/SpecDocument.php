<?php
declare(strict_types=1);

/**
 * 规格书预处理：把上传的文件变成“页面图片 + 文字”，交给识图模型。
 *
 * - 图片：转成 JPG（长边最多 1800px）
 * - PDF：每页转一张图（pdftoppm），同时取文字（pdftotext）
 * - Word / Excel：有 LibreOffice 时先转 PDF 再按页转图；没有时取文档里的图片和文字
 * - ZIP：逐个处理里面的图片、PDF、Word、Excel
 *
 * 最多处理 $maxPages 页。
 */
final class SpecDocument
{
    private const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    /** @var string */
    private $outDir;

    /** @var int */
    private $maxPages;

    /** @var list<string> 页面图片文件名 */
    private $pages = [];

    /** @var list<string> */
    private $texts = [];

    /** @var list<string> */
    private $notes = [];

    public function __construct(string $outDir, int $maxPages = 20)
    {
        $this->outDir = rtrim($outDir, '/');
        $this->maxPages = max(1, $maxPages);
        if (!is_dir($this->outDir) && !mkdir($this->outDir, 0750, true) && !is_dir($this->outDir)) {
            throw new RuntimeException('无法创建页面目录');
        }
    }

    /**
     * @return array{pages: list<string>, text: string, notes: list<string>}
     */
    public function process(string $file, string $originalName, array $browserPages = [], string $browserText = ''): array
    {
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if ($ext === 'pdf' && $browserPages) {
            // 浏览器已经把 PDF 逐页转成图片（服务器禁用了 exec 时靠这个）
            foreach ($browserPages as $img) {
                $this->addImage($img);
            }
            if (trim($browserText) !== '') {
                $this->texts[] = '【' . $originalName . '】' . "\n" . mb_substr($browserText, 0, 20000, 'UTF-8');
            }
        } else {
            $this->handle($file, $ext, $originalName, 0);
        }
        if (!$this->pages) {
            throw new RuntimeException('没能从文件里取出可识别的页面或图片' . ($this->notes ? '：' . implode('；', $this->notes) : ''));
        }
        return ['pages' => $this->pages, 'text' => trim(implode("\n\n", $this->texts)), 'notes' => $this->notes];
    }

    private function full(): bool
    {
        return count($this->pages) >= $this->maxPages;
    }

    private function handle(string $file, string $ext, string $label, int $depth): void
    {
        if ($this->full()) {
            return;
        }
        if (in_array($ext, self::IMAGE_EXT, true)) {
            $this->addImage($file);
        } elseif ($ext === 'pdf') {
            $this->addPdf($file, $label);
        } elseif (in_array($ext, ['docx', 'xlsx', 'doc', 'xls'], true)) {
            $this->addOffice($file, $ext, $label);
        } elseif ($ext === 'zip' && $depth === 0) {
            $this->addZip($file);
        } else {
            $this->notes[] = $label . '：不支持的文件类型，已跳过';
        }
    }

    /** 保存为下一页（JPG）。 */
    private function addImage(string $file): void
    {
        if ($this->full()) {
            return;
        }
        $name = 'p-' . (count($this->pages) + 1) . '.jpg';
        $dest = $this->outDir . '/' . $name;
        if (!self::toJpeg($file, $dest, 1800)) {
            $this->notes[] = basename($file) . '：图片读不出来，已跳过';
            return;
        }
        $this->pages[] = $name;
    }

    private function addPdf(string $file, string $label): void
    {
        $left = $this->maxPages - count($this->pages);
        if ($left <= 0) {
            return;
        }
        $pdfinfo = self::tool('pdfinfo');
        $total = null;
        if ($pdfinfo) {
            $info = self::run([$pdfinfo, $file]);
            if (preg_match('/^Pages:\s+(\d+)/m', $info, $m)) {
                $total = (int) $m[1];
            }
        }
        $last = $total !== null ? min($total, $left) : $left;
        if ($total !== null && $total > $left) {
            $this->notes[] = $label . ' 共 ' . $total . ' 页，只处理了前 ' . $last . ' 页';
        }
        $pdftotext = self::tool('pdftotext');
        if ($pdftotext) {
            $text = self::run([$pdftotext, '-layout', '-f', '1', '-l', (string) $last, $file, '-']);
            if (trim($text) !== '') {
                $this->texts[] = '【' . $label . '】' . "\n" . mb_substr($text, 0, 20000, 'UTF-8');
            }
        }
        $pdftoppm = self::tool('pdftoppm');
        $tmp = $this->outDir . '/_pdf_' . bin2hex(random_bytes(4));
        mkdir($tmp, 0750);
        if ($pdftoppm) {
            self::run([$pdftoppm, '-r', '110', '-jpeg', '-jpegopt', 'quality=85', '-f', '1', '-l', (string) $last, $file, $tmp . '/pg']);
        } elseif (class_exists('Imagick')) {
            for ($i = 0; $i < $last; $i++) {
                try {
                    $im = new Imagick();
                    $im->setResolution(110, 110);
                    $im->readImage($file . '[' . $i . ']');
                    $im->setImageFormat('jpeg');
                    $im->writeImage(sprintf('%s/pg-%03d.jpg', $tmp, $i + 1));
                    $im->clear();
                } catch (Throwable $e) {
                    break;
                }
            }
        } else {
            rmdir($tmp);
            throw new RuntimeException('服务器不能直接转换 PDF。请刷新页面后重新上传（浏览器会先把 PDF 转成图片）');
        }
        $files = glob($tmp . '/pg-*.jpg') ?: [];
        natsort($files);
        foreach ($files as $f) {
            $this->addImage($f);
            @unlink($f);
        }
        @rmdir($tmp);
        if (!$files) {
            $this->notes[] = $label . '：PDF 转图片失败';
        }
    }

    private function addOffice(string $file, string $ext, string $label): void
    {
        $soffice = self::tool('soffice') ?? self::tool('libreoffice');
        if ($soffice) {
            $tmp = $this->outDir . '/_office_' . bin2hex(random_bytes(4));
            mkdir($tmp, 0750);
            $src = $tmp . '/in.' . $ext;
            copy($file, $src);
            self::run([$soffice, '--headless', '-env:UserInstallation=file://' . $tmp . '/profile', '--convert-to', 'pdf', '--outdir', $tmp, $src], 120);
            $pdf = $tmp . '/in.pdf';
            if (is_file($pdf)) {
                $this->addPdf($pdf, $label);
                self::rrmdir($tmp);
                return;
            }
            self::rrmdir($tmp);
        }
        if (!in_array($ext, ['docx', 'xlsx'], true) || !class_exists('ZipArchive')) {
            $this->notes[] = $label . '：服务器没有 LibreOffice，无法读取 .' . $ext . '（可另存为 PDF 再上传）';
            return;
        }
        $zip = new ZipArchive();
        if ($zip->open($file) !== true) {
            $this->notes[] = $label . '：文件损坏，无法打开';
            return;
        }
        $textParts = [];
        $mediaDir = $ext === 'docx' ? 'word/media/' : 'xl/media/';
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = (string) $zip->getNameIndex($i);
            if (in_array($name, ['word/document.xml', 'xl/sharedStrings.xml'], true)) {
                $xml = (string) $zip->getFromIndex($i);
                $xml = preg_replace('#</(w:p|si|w:tr)>#', "\n", $xml);
                $xml = preg_replace('#</(w:tc)>#', "\t", (string) $xml);
                $textParts[] = html_entity_decode(strip_tags((string) $xml), ENT_QUOTES | ENT_XML1, 'UTF-8');
            }
            $iext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (strpos($name, $mediaDir) === 0 && in_array($iext, self::IMAGE_EXT, true) && !$this->full()) {
                $data = (string) $zip->getFromIndex($i);
                if (strlen($data) < 4000) {
                    continue; // 图标、线条之类的小图
                }
                $tmpImg = $this->outDir . '/_m_' . bin2hex(random_bytes(4)) . '.' . $iext;
                file_put_contents($tmpImg, $data);
                $this->addImage($tmpImg);
                @unlink($tmpImg);
            }
        }
        $zip->close();
        $text = trim(implode("\n", $textParts));
        if ($text !== '') {
            $this->texts[] = '【' . $label . '】' . "\n" . mb_substr($text, 0, 20000, 'UTF-8');
        }
        $this->notes[] = $label . '：服务器没有 LibreOffice，只取了文档里的图片和文字';
    }

    private function addZip(string $file): void
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('服务器 PHP 缺少 zip 扩展，无法读取压缩包');
        }
        $zip = new ZipArchive();
        if ($zip->open($file) !== true) {
            throw new RuntimeException('压缩包无法打开');
        }
        $tmp = $this->outDir . '/_zip_' . bin2hex(random_bytes(4));
        mkdir($tmp, 0750);
        $names = [];
        for ($i = 0; $i < $zip->numFiles && $i < 500; $i++) {
            $names[$i] = (string) $zip->getNameIndex($i);
        }
        natcasesort($names);
        foreach ($names as $i => $name) {
            if ($this->full()) {
                break;
            }
            if (substr($name, -1) === '/' || strpos($name, '__MACOSX') !== false || strpos(basename($name), '.') === 0) {
                continue;
            }
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, array_merge(self::IMAGE_EXT, ['pdf', 'docx', 'xlsx', 'doc', 'xls']), true)) {
                continue;
            }
            $stat = $zip->statIndex($i);
            if (!$stat || $stat['size'] > 60 * 1024 * 1024) {
                $this->notes[] = $name . '：太大，已跳过';
                continue;
            }
            $dest = $tmp . '/' . $i . '.' . $ext; // 不用压缩包里的路径，防止路径穿越
            file_put_contents($dest, (string) $zip->getFromIndex($i));
            $this->handle($dest, $ext, basename($name), 1);
            @unlink($dest);
        }
        $zip->close();
        self::rrmdir($tmp);
    }

    /** 转 JPG，长边不超过 $max；透明背景填白。 */
    public static function toJpeg(string $src, string $dest, int $max): bool
    {
        $info = @getimagesize($src);
        if (!$info || !function_exists('imagecreatetruecolor')) {
            return $info !== false && @copy($src, $dest);
        }
        switch ($info[2]) {
            case IMAGETYPE_JPEG:
                $im = @imagecreatefromjpeg($src);
                break;
            case IMAGETYPE_PNG:
                $im = @imagecreatefrompng($src);
                break;
            case IMAGETYPE_GIF:
                $im = @imagecreatefromgif($src);
                break;
            case IMAGETYPE_WEBP:
                $im = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($src) : false;
                break;
            default:
                $im = false;
        }
        if (!$im) {
            return false;
        }
        $w = imagesx($im);
        $h = imagesy($im);
        $scale = min(1, $max / max($w, $h));
        $nw = max(1, (int) round($w * $scale));
        $nh = max(1, (int) round($h * $scale));
        $out = imagecreatetruecolor($nw, $nh);
        imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
        imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
        $ok = imagejpeg($out, $dest, 85);
        imagedestroy($im);
        imagedestroy($out);
        return $ok;
    }

    /** 服务器是否允许调用外部程序（宝塔默认禁用 exec）。 */
    public static function canExec(): bool
    {
        return function_exists('exec') && function_exists('escapeshellarg');
    }

    public static function tool(string $name): ?string
    {
        if (!self::canExec()) {
            return null;
        }
        foreach (['/usr/bin/', '/usr/local/bin/', '/opt/homebrew/bin/', '/bin/'] as $dir) {
            if (is_file($dir . $name) && is_executable($dir . $name)) {
                return $dir . $name;
            }
        }
        return null;
    }

    /** @param list<string> $cmd */
    private static function run(array $cmd, int $timeout = 90): string
    {
        $line = implode(' ', array_map('escapeshellarg', $cmd));
        if (self::tool('timeout')) {
            $line = escapeshellarg((string) self::tool('timeout')) . ' ' . $timeout . ' ' . $line;
        }
        $out = [];
        exec($line . ' 2>/dev/null', $out);
        return implode("\n", $out);
    }

    private static function rrmdir(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $f) {
            $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
        }
        @rmdir($dir);
    }
}
