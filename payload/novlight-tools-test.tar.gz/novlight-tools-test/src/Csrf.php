<?php
declare(strict_types=1);

final class Csrf
{
    private const KEY = '_csrf_token';

    public static function token(): string
    {
        if (empty($_SESSION[self::KEY])) {
            $_SESSION[self::KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::KEY];
    }

    public static function field(): string
    {
        $t = htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="_csrf" value="' . $t . '">';
    }

    public static function validate(?string $token): bool
    {
        if ($token === null || $token === '') {
            return false;
        }
        $session = $_SESSION[self::KEY] ?? '';
        return is_string($session) && $session !== '' && hash_equals($session, $token);
    }

    public static function requireValid(): void
    {
        $token = $_POST['_csrf'] ?? null;
        if (!self::validate(is_string($token) ? $token : null)) {
            http_response_code(403);
            echo 'CSRF 校验失败，请刷新页面后重试。';
            exit;
        }
    }
}
