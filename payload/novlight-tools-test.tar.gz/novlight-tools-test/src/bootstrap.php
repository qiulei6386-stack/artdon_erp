<?php
declare(strict_types=1);

$config = require dirname(__DIR__) . '/config.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Shanghai');

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/Csrf.php';
require_once __DIR__ . '/Upload.php';
require_once __DIR__ . '/TencentTiiaClient.php';
require_once __DIR__ . '/ImageSearch.php';
require_once __DIR__ . '/ProductParams.php';
require_once __DIR__ . '/SpecDocument.php';
require_once __DIR__ . '/SpecExtractor.php';
require_once __DIR__ . '/SpecMatcher.php';
require_once __DIR__ . '/SpecRun.php';

Auth::startSession($config);
$pdo = Database::pdo($config);

function e(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function render(string $template, array $vars = []): void
{
    global $config;
    extract($vars, EXTR_SKIP);
    $user = Auth::user();
    $appName = $config['app_name'] ?? 'Novlight 工具台';
    require dirname(__DIR__) . '/templates/layout.php';
}

function flash_set(string $type, string $message): void
{
    $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array
{
    if (empty($_SESSION['_flash'])) {
        return null;
    }
    $f = $_SESSION['_flash'];
    unset($_SESSION['_flash']);
    return $f;
}
