<?php
declare(strict_types=1);

/**
 * 按参数给规格书里的每款灯找最接近的自家产品。
 *
 * 每一项只在双方都有数据时才计分；最后得分 = 得到的分 ÷ 可得的分。
 * 类型不在同一大类（如筒灯对导轨灯）的产品不参与。
 * 对方要求而我们没有的（开孔装不下、IP 不够、色温/调光不支持…）列为“差异”，供报价时确认。
 */
final class SpecMatcher
{
    /** @var PDO */
    private $pdo;

    /** @var list<array<string, mixed>>|null */
    private $products;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /** @return list<array<string, mixed>> */
    public function products(): array
    {
        if ($this->products === null) {
            $this->products = $this->pdo->query(
                "SELECT id, name, model, series, category, price, currency, image_stored_name, catalog_page,
                        cut_out, dimensions, power, luminous_flux, adjustability, beam_angle, cct, cri, ugr, dimming_method, ip_rating,
                        power_watts, type_key, cutout_mm, diameter_mm, height_mm, lumen, adjustable, tilt_deg, rotation_deg,
                        beam_min, beam_max, cct_min, cct_max, cri_num, ugr_max, ip_num, wall_wash
                 FROM products WHERE COALESCE(is_active, 1) = 1 AND model <> ''"
            )->fetchAll(PDO::FETCH_ASSOC);
        }
        return $this->products;
    }

    /**
     * @param array<string, mixed> $item SpecExtractor::normalize() 的结果
     * @return list<array<string, mixed>> 候选（按分数从高到低）
     */
    public function match(array $item, int $limit = 5): array
    {
        $scored = [];
        foreach ($this->products() as $p) {
            $r = self::score($item, $p);
            if ($r !== null) {
                $scored[] = $r + ['product' => $p];
            }
        }
        usort($scored, static function (array $a, array $b): int {
            return [$b['score'], -$b['watt_gap']] <=> [$a['score'], -$a['watt_gap']];
        });
        return array_slice($scored, 0, $limit);
    }

    /**
     * 给一款产品打分；类型不相干时返回 null。
     *
     * @return array{score: int, reasons: list<string>, gaps: list<string>, watt_gap: float}|null
     */
    public static function score(array $it, array $p): ?array
    {
        $earned = 0.0;
        $possible = 0.0;
        $reasons = [];
        $gaps = [];
        $add = static function (float $weight, float $got) use (&$earned, &$possible): void {
            $possible += $weight;
            $earned += max(0.0, min($weight, $got));
        };
        $n = static function ($v): ?float {
            return $v === null || $v === '' ? null : (float) $v;
        };

        // 类型
        $itType = (string) ($it['type'] ?? 'other');
        $pType = (string) ($p['type_key'] ?? '') !== '' ? (string) $p['type_key'] : 'other';
        if ($itType !== 'other') {
            $ig = ProductParams::GROUPS[$itType] ?? 'other';
            $pg = ProductParams::GROUPS[$pType] ?? 'other';
            if ($itType === $pType) {
                $add(30, 30);
                $reasons[] = '类型相同（' . (ProductParams::TYPES[$pType] ?? $pType) . '）';
            } elseif ($ig === $pg && $ig !== 'other') {
                // 筒灯 / 射灯在各家目录里叫法不一，几乎等同；其他同组类型打折更多
                $near = [$itType, $pType] == ['recessed_downlight', 'recessed_spotlight'] || [$itType, $pType] == ['recessed_spotlight', 'recessed_downlight'];
                $add(30, $near ? 27 : 18);
                $reasons[] = '同属' . self::groupLabel($ig);
            } else {
                return null;
            }
        }

        // 开孔
        $ic = $n($it['cutout_mm'] ?? null);
        $pc = $n($p['cutout_mm'] ?? null);
        if ($ic !== null && $ic > 0) {
            if ($pc === null) {
                $add(20, 0);
            } else {
                $d = $pc - $ic;
                if (abs($d) <= 2) {
                    $add(20, 20);
                    $reasons[] = '开孔 ' . self::fmt($pc) . 'mm 一致';
                } elseif ($d > 2) {
                    $add(20, 0);
                    $gaps[] = '开孔 ' . self::fmt($pc) . 'mm，比对方大 ' . self::fmt($d) . 'mm，原孔装不下';
                } elseif ($d >= -10) {
                    $add(20, 12);
                    $gaps[] = '开孔 ' . self::fmt($pc) . 'mm，比对方小 ' . self::fmt(-$d) . 'mm，需要加大面环或转接';
                } else {
                    $add(20, 4);
                    $gaps[] = '开孔 ' . self::fmt($pc) . 'mm，比对方小 ' . self::fmt(-$d) . 'mm';
                }
            }
        } elseif (($id = $n($it['diameter_mm'] ?? null)) !== null && ($pd = $n($p['diameter_mm'] ?? null)) !== null) {
            $d = abs($pd - $id);
            $add(8, $d <= 5 ? 8 : ($d <= 15 ? 4 : 0));
            if ($d <= 5) {
                $reasons[] = '直径接近（' . self::fmt($pd) . 'mm）';
            }
        }

        // 高度
        $ih = $n($it['height_mm'] ?? null);
        $ph = $n($p['height_mm'] ?? null);
        if ($ih !== null && $ph !== null && $ih > 0) {
            $d = $ph - $ih;
            $add(4, abs($d) <= 10 ? 4 : (abs($d) <= 25 ? 2 : 0));
            if ($d > 10) {
                $gaps[] = '灯体高 ' . self::fmt($ph) . 'mm，比对方高 ' . self::fmt($d) . 'mm';
            }
        }

        // 功率、光通量
        $iw = $n($it['watt'] ?? null);
        $pw = $n($p['power_watts'] ?? null);
        $wattGap = 1.0;
        if ($iw !== null && $iw > 0 && $pw !== null) {
            $rel = abs($pw - $iw) / $iw;
            $wattGap = $rel;
            $add(15, $rel <= 0.1 ? 15 : ($rel <= 0.25 ? 10 : ($rel <= 0.5 ? 5 : 0)));
            if ($rel <= 0.1) {
                $reasons[] = '功率 ' . self::fmt($pw) . 'W 接近';
            } elseif ($rel > 0.25) {
                $gaps[] = '功率 ' . self::fmt($pw) . 'W，对方 ' . self::fmt($iw) . 'W';
            }
        }
        $il = $n($it['lumen'] ?? null);
        $pl = $n($p['lumen'] ?? null);
        if ($il !== null && $il > 0 && $pl !== null) {
            $rel = abs($pl - $il) / $il;
            $add(10, $rel <= 0.1 ? 10 : ($rel <= 0.25 ? 7 : ($rel <= 0.5 ? 3 : 0)));
            if ($rel <= 0.1) {
                $reasons[] = '光通量 ' . self::fmt($pl) . 'lm 接近';
            } elseif ($rel > 0.25) {
                $gaps[] = '光通量 ' . self::fmt($pl) . 'lm，对方 ' . self::fmt($il) . 'lm';
            }
        }

        // 可调
        if (isset($it['adjustable']) && $it['adjustable'] !== null) {
            $pa = (int) ($p['adjustable'] ?? 0) === 1;
            $add(8, $pa === (bool) $it['adjustable'] ? 8 : 0);
            if ($pa !== (bool) $it['adjustable']) {
                $gaps[] = $pa ? '我们是可调角，对方是固定' : '我们是固定的，对方要求可调角';
            } elseif ($pa) {
                $reasons[] = '可调角';
            }
        }
        $it_t = $n($it['tilt_deg'] ?? null);
        $pt = $n($p['tilt_deg'] ?? null);
        if ($it_t !== null && $it_t > 0 && $pt !== null) {
            $add(4, min(1, $pt / $it_t) * 4);
            if ($pt + 2 < $it_t) {
                $gaps[] = '调角 ' . self::fmt($pt) . '°，对方 ' . self::fmt($it_t) . '°';
            }
        }

        // 光束角：看我们能不能做到对方最窄的那个
        $beams = array_values(array_filter((array) ($it['beam_angles'] ?? []), 'is_numeric'));
        $pbMin = $n($p['beam_min'] ?? null);
        if ($beams && $pbMin !== null) {
            $need = min($beams);
            $ok = $pbMin <= $need + 3;
            $add(5, $ok ? 5 : 2);
            if (!$ok) {
                $gaps[] = '最窄光束 ' . self::fmt($pbMin) . '°，对方要 ' . self::fmt($need) . '°';
            }
        }

        // 防眩
        $iu = $n($it['ugr_max'] ?? null);
        if ($iu !== null && $iu > 0) {
            $pu = $n($p['ugr_max'] ?? null);
            if ($pu === null) {
                $add(4, 1);
                $gaps[] = 'UGR 目录未标注，对方要求 <' . self::fmt($iu);
            } elseif ($pu <= $iu) {
                $add(4, 4);
                $reasons[] = 'UGR<' . self::fmt($pu) . '（对方 <' . self::fmt($iu) . '）';
            } else {
                $add(4, 1);
                $gaps[] = 'UGR<' . self::fmt($pu) . '，对方要 <' . self::fmt($iu);
            }
        }

        // 显指
        $icri = $n($it['cri'] ?? null);
        $pcri = $n($p['cri_num'] ?? null);
        if ($icri !== null && $pcri !== null) {
            $add(3, $pcri >= $icri ? 3 : 1);
            if ($pcri < $icri) {
                $gaps[] = '显指 ' . self::fmt($pcri) . '，对方要 ' . self::fmt($icri) . '+';
            }
        }

        // 防护
        $iip = $n($it['ip'] ?? null);
        if ($iip !== null && $iip > 20) {
            $pip = $n($p['ip_num'] ?? null) ?? 20.0;
            $add(4, $pip >= $iip ? 4 : 0);
            if ($pip < $iip) {
                $gaps[] = 'IP' . self::fmt($iip) . ' 需另询（目录为 IP' . self::fmt($pip) . '）';
            }
        }

        // 色温
        $ccts = array_values(array_filter((array) ($it['cct'] ?? []), 'is_numeric'));
        $cmin = $n($p['cct_min'] ?? null);
        $cmax = $n($p['cct_max'] ?? null);
        if ($ccts && $cmin !== null && $cmax !== null) {
            $miss = array_values(array_filter($ccts, static function ($c) use ($cmin, $cmax) {
                return $c < $cmin - 50 || $c > $cmax + 50;
            }));
            $add(3, 3 * (1 - count($miss) / count($ccts)));
            if ($miss) {
                $gaps[] = implode('/', array_map(static function ($c) {
                    return self::fmt($c) . 'K';
                }, $miss)) . ' 需另询';
            }
        }

        // 调光
        $dims = (array) ($it['dimming'] ?? []);
        $pdim = strtolower((string) ($p['dimming_method'] ?? ''));
        if ($dims && $pdim !== '') {
            $miss = [];
            foreach ($dims as $d) {
                $key = strtolower(str_replace([' ', '–'], ['', '-'], (string) $d));
                if (in_array($key, ['on/off', 'onoff', 'switch', 'non-dim', 'non-dimmable'], true)) {
                    continue;
                }
                $k = str_replace(['1-10v', '0/1-10v'], '0-10v', $key);
                if (strpos(str_replace(' ', '', $pdim), $k) === false) {
                    $miss[] = (string) $d;
                }
            }
            $add(2, $miss ? 0.5 : 2);
            if ($miss) {
                $gaps[] = implode(' / ', $miss) . ' 调光需另询';
            }
        }

        $score = $possible > 0 ? (int) round($earned / $possible * 100) : 0;
        return ['score' => $score, 'reasons' => $reasons, 'gaps' => $gaps, 'watt_gap' => $wattGap];
    }

    private static function groupLabel(string $g): string
    {
        return ['recessed' => '嵌入式', 'track' => '轨道灯', 'linear' => '线条灯', 'cabinet' => '柜灯', 'surface' => '明装灯', 'pendant' => '吊灯'][$g] ?? $g;
    }

    /** @param float|int $v */
    public static function fmt($v): string
    {
        $f = (float) $v;
        return abs($f - round($f)) < 0.01 ? (string) (int) round($f) : rtrim(rtrim(number_format($f, 1, '.', ''), '0'), '.');
    }
}
