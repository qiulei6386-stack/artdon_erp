<?php
declare(strict_types=1);

/**
 * 读规格书：把页面图片和文字交给识图大模型，拿回每款灯具的类型、外观和参数（JSON）。
 *
 * 提供方（config['spec']['provider']）：
 * - qwen：通义千问视觉模型（阿里云百炼，OpenAI 兼容接口）
 * - hunyuan：腾讯混元视觉模型（旧混元平台 api.hunyuan.cloud.tencent.com）
 * - tokenhub：腾讯云 TokenHub（混元迁移后的新平台），默认用 hy-vision-2.0-instruct 看图
 * - fixture：测试用，按文件名读 tests/fixtures/ 里预先写好的结果，不调用任何接口
 */
final class SpecExtractor
{
    /** @var array<string, mixed> */
    private $cfg;

    /** @var callable|null 测试时替换 HTTP 请求 */
    private $http;

    public function __construct(array $config, ?callable $http = null)
    {
        $this->cfg = self::settings($config);
        $this->http = $http;
    }

    /** @return array<string, mixed> */
    public static function settings(array $config): array
    {
        $spec = is_array($config['spec'] ?? null) ? $config['spec'] : [];
        $provider = (string) ($spec['provider'] ?? 'qwen');
        // 各家默认值；config 里写了就以 config 为准
        $presets = [
            'qwen' => ['https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', 'qwen-vl-max', '/www/server/artdon_secrets/dashscope.php', 'DASHSCOPE_API_KEY'],
            'hunyuan' => ['https://api.hunyuan.cloud.tencent.com/v1/chat/completions', 'hunyuan-vision', '/www/server/artdon_secrets/hunyuan.php', 'HUNYUAN_API_KEY'],
            'tokenhub' => ['https://tokenhub.tencentmaas.com/v1/chat/completions', 'hy-vision-2.0-instruct', '/www/server/artdon_secrets/hunyuan.php', 'TOKENHUB_API_KEY'],
        ];
        [$endpoint, $model, $secretsFile, $env] = $presets[$provider] ?? $presets['qwen'];
        $secrets = [];
        $file = (string) ($spec['secrets_file'] ?? $secretsFile);
        if ($file !== '' && is_readable($file)) {
            $loaded = include $file;
            $secrets = is_array($loaded) ? $loaded : [];
        }
        $key = (string) ($spec['api_key'] ?? '');
        if ($key === '') {
            $key = (string) ($secrets['api_key'] ?? (getenv($env) ?: ''));
        }
        return [
            'provider' => $provider,
            'api_key' => $key,
            'endpoint' => (string) ($spec['endpoint'] ?? $endpoint),
            'model' => (string) ($spec['model'] ?? $model),
            'pages_per_request' => max(1, (int) ($spec['pages_per_request'] ?? 4)),
            'timeout' => max(10, (int) ($spec['timeout'] ?? 150)),
            'max_pages' => max(1, (int) ($spec['max_pages'] ?? 20)),
            // 额外请求参数；tokenhub 默认关掉“思考”模式，回答更快
            'extra_body' => is_array($spec['extra_body'] ?? null) ? $spec['extra_body'] : ($provider === 'tokenhub' ? ['enable_thinking' => false] : []),
            'fixture_dir' => (string) ($spec['fixture_dir'] ?? dirname(__DIR__) . '/tests/fixtures'),
        ];
    }

    public function provider(): string
    {
        return $this->cfg['provider'];
    }

    public function maxPages(): int
    {
        return $this->cfg['max_pages'];
    }

    /** 现在能不能用（缺密钥时页面上提示）。 */
    public function ready(): bool
    {
        return $this->cfg['provider'] === 'fixture' || $this->cfg['api_key'] !== '';
    }

    /**
     * @param list<string> $pageFiles 页面图片的完整路径
     * @return list<array<string, mixed>> 识别出的灯具
     */
    public function extract(array $pageFiles, string $text, string $originalName): array
    {
        if ($this->cfg['provider'] === 'fixture') {
            return $this->fixture($originalName);
        }
        if ($this->cfg['api_key'] === '') {
            throw new RuntimeException('还没有配置通义千问的接口密钥（阿里云百炼 API Key），请联系管理员在服务器上配置');
        }
        $items = [];
        $chunks = array_chunk($pageFiles, $this->cfg['pages_per_request']);
        foreach ($chunks as $ci => $chunk) {
            $firstPage = $ci * $this->cfg['pages_per_request'] + 1;
            $raw = $this->ask($chunk, $ci === 0 ? $text : '', $firstPage);
            foreach (self::parse($raw) as $item) {
                $items[] = $item;
            }
        }
        return self::merge($items);
    }

    /** @param list<string> $files */
    private function ask(array $files, string $text, int $firstPage): string
    {
        $content = [['type' => 'text', 'text' => self::promptFor($firstPage, count($files))]];
        if ($text !== '') {
            $content[] = ['type' => 'text', 'text' => "文件里可以直接读到的文字（供参考，可能不全）：\n" . mb_substr($text, 0, 8000, 'UTF-8')];
        }
        foreach ($files as $f) {
            $content[] = ['type' => 'image_url', 'image_url' => ['url' => 'data:image/jpeg;base64,' . base64_encode((string) file_get_contents($f))]];
        }
        $body = json_encode([
            'model' => $this->cfg['model'],
            'messages' => [['role' => 'user', 'content' => $content]],
            'temperature' => 0.1,
        ] + $this->cfg['extra_body'], JSON_UNESCAPED_UNICODE);
        $resp = $this->post($this->cfg['endpoint'], (string) $body);
        $data = json_decode($resp, true);
        if (!is_array($data)) {
            throw new RuntimeException('识图接口返回的内容无法解析');
        }
        if (isset($data['error'])) {
            $msg = is_array($data['error']) ? (string) ($data['error']['message'] ?? json_encode($data['error'])) : (string) $data['error'];
            throw new RuntimeException('识图接口报错：' . $msg);
        }
        return (string) ($data['choices'][0]['message']['content'] ?? '');
    }

    /** 带页码范围的说明文字。 */
    public static function promptFor(int $firstPage, int $count): string
    {
        $last = $firstPage + $count - 1;
        $types = implode(' / ', array_keys(ProductParams::TYPES));
        return "你是照明灯具选型工程师。下面是客户规格书（或产品图片）的第 {$firstPage}～{$last} 页。\n"
            . "请找出其中的每一款灯具（同一型号跨多页只算一款），逐款提取参数，只输出 JSON，不要任何解释。格式：\n"
            . '{"items":[{"page":页码,"brand":"品牌","model":"产品型号名（如 SAIL；没有型号名才填订货号）","name":"产品名称",'
            . '"type":"' . $types . ' 之一","adjustable":true或false(能否调角度),'
            . '"cutout_mm":开孔尺寸,"diameter_mm":外径或宽,"height_mm":高度,"length_mm":长度(线条灯),'
            . '"watt":功率W,"lumen":光通量lm,"beam_angles":[光束角...],"cct":[色温K...],"cri":显指最小值,'
            . '"ugr_max":UGR上限,"ip":防护等级数字如54,"tilt_deg":垂直可调角度,"rotation_deg":水平旋转角度,'
            . '"dimming":["ON/OFF","DALI","0-10V","TRIAC","Casambi"...],"colors":["white","black"...],'
            . '"appearance":"一句话描述外观(形状、颜色、散热结构、安装方式)","quantity":数量,"notes":"其他关键要求（订货号也写在这里）"}]}' . "\n"
            . "没有的字段填 null；数字只写数字不带单位；看不清的不要猜。";
    }

    private function post(string $url, string $body): string
    {
        if ($this->http) {
            return (string) ($this->http)($url, $body, $this->cfg);
        }
        if (!function_exists('curl_init')) {
            throw new RuntimeException('服务器 PHP 缺少 curl 扩展');
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->cfg['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->cfg['api_key'],
            ],
        ]);
        $resp = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($resp === false) {
            throw new RuntimeException('连接识图接口失败：' . $err);
        }
        if ($code >= 400) {
            $d = json_decode((string) $resp, true);
            $msg = is_array($d) ? (string) ($d['error']['message'] ?? $d['message'] ?? '') : '';
            throw new RuntimeException('识图接口返回错误 ' . $code . ($msg !== '' ? '：' . $msg : ''));
        }
        return (string) $resp;
    }

    /**
     * 从模型回答里取出 JSON 并规范字段。
     *
     * @return list<array<string, mixed>>
     */
    public static function parse(string $raw): array
    {
        $raw = trim($raw);
        $raw = (string) preg_replace('/^```(?:json)?\s*|\s*```$/m', '', $raw);
        $start = strpos($raw, '{');
        $end = strrpos($raw, '}');
        if ($start === false || $end === false) {
            return [];
        }
        $data = json_decode(substr($raw, $start, $end - $start + 1), true);
        if (!is_array($data)) {
            return [];
        }
        $list = isset($data['items']) && is_array($data['items']) ? $data['items'] : (array_is_list_compat($data) ? $data : [$data]);
        $out = [];
        foreach ($list as $it) {
            if (is_array($it)) {
                $out[] = self::normalize($it);
            }
        }
        return $out;
    }

    /** @param array<string, mixed> $it @return array<string, mixed> */
    public static function normalize(array $it): array
    {
        $num = static function ($v): ?float {
            if (is_int($v) || is_float($v)) {
                return (float) $v;
            }
            if (is_string($v) && preg_match('/-?\d+(?:\.\d+)?/', $v, $m)) {
                return (float) $m[0];
            }
            return null;
        };
        $nums = static function ($v) use ($num): array {
            if (!is_array($v)) {
                $v = is_string($v) ? preg_split('/[\/,，、\s]+/', $v) : [$v];
            }
            $out = [];
            foreach ((array) $v as $x) {
                $n = $num($x);
                if ($n !== null) {
                    $out[] = $n;
                }
            }
            return array_values(array_unique($out));
        };
        $strs = static function ($v): array {
            if (is_string($v)) {
                $v = preg_split('/[\/,，、]+/', $v);
            }
            return array_values(array_filter(array_map(static function ($x) {
                return is_scalar($x) ? trim((string) $x) : '';
            }, (array) $v), 'strlen'));
        };
        $type = is_string($it['type'] ?? null) ? strtolower(trim($it['type'])) : 'other';
        if (!isset(ProductParams::TYPES[$type])) {
            $type = ProductParams::typeFromCategory($type);
        }
        $adj = $it['adjustable'] ?? null;
        $tilt = $num($it['tilt_deg'] ?? null);
        return [
            'page' => (int) ($num($it['page'] ?? null) ?? 0),
            'brand' => self::str($it['brand'] ?? ''),
            'model' => self::str($it['model'] ?? ''),
            'name' => self::str($it['name'] ?? ''),
            'type' => $type,
            'adjustable' => $adj === null ? ($tilt !== null && $tilt > 0 ? true : null) : (bool) $adj,
            'cutout_mm' => $num($it['cutout_mm'] ?? null),
            'diameter_mm' => $num($it['diameter_mm'] ?? null),
            'height_mm' => $num($it['height_mm'] ?? null),
            'length_mm' => $num($it['length_mm'] ?? null),
            'watt' => $num($it['watt'] ?? null),
            'lumen' => $num($it['lumen'] ?? null),
            'beam_angles' => $nums($it['beam_angles'] ?? []),
            'cct' => array_values(array_filter($nums($it['cct'] ?? []), static function ($v) {
                return $v >= 1000;
            })),
            'cri' => $num($it['cri'] ?? null),
            'ugr_max' => $num($it['ugr_max'] ?? null),
            'ip' => $num($it['ip'] ?? null),
            'tilt_deg' => $tilt,
            'rotation_deg' => $num($it['rotation_deg'] ?? null),
            'dimming' => $strs($it['dimming'] ?? []),
            'colors' => $strs($it['colors'] ?? []),
            'appearance' => self::str($it['appearance'] ?? ''),
            'quantity' => ($q = $num($it['quantity'] ?? null)) !== null ? (int) $q : null,
            'notes' => self::str($it['notes'] ?? ''),
        ];
    }

    /**
     * 不同批次识别出的同一型号合并成一条（先出现的值优先，空的用后面的补）。
     *
     * @param list<array<string, mixed>> $items
     * @return list<array<string, mixed>>
     */
    public static function merge(array $items): array
    {
        $out = [];
        $index = [];
        foreach ($items as $it) {
            $key = $it['model'] !== '' ? strtolower($it['brand'] . '|' . $it['model']) : null;
            if ($key !== null && isset($index[$key])) {
                $cur = &$out[$index[$key]];
                foreach ($it as $k => $v) {
                    if ($cur[$k] === null || $cur[$k] === '' || $cur[$k] === []) {
                        $cur[$k] = $v;
                    }
                }
                unset($cur);
                continue;
            }
            if ($key !== null) {
                $index[$key] = count($out);
            }
            $out[] = $it;
        }
        return $out;
    }

    /** @return list<array<string, mixed>> */
    private function fixture(string $originalName): array
    {
        $base = pathinfo($originalName, PATHINFO_FILENAME);
        foreach ([$base . '.json', 'default.json'] as $f) {
            $path = $this->cfg['fixture_dir'] . '/' . $f;
            if (is_file($path)) {
                return self::merge(self::parse((string) file_get_contents($path)));
            }
        }
        throw new RuntimeException('测试模式下找不到 ' . $base . '.json');
    }

    private static function str($v): string
    {
        return is_scalar($v) ? mb_substr(trim((string) $v), 0, 500, 'UTF-8') : '';
    }
}

/** PHP 8.0 没有 array_is_list。 */
function array_is_list_compat(array $a): bool
{
    return $a === [] || array_keys($a) === range(0, count($a) - 1);
}
