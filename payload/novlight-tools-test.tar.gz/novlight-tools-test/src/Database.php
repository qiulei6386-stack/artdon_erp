<?php
declare(strict_types=1);

final class Database
{
    private static ?PDO $pdo = null;

    public static function pdo(array $config): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $path = $config['db_path'];
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }

        $pdo = new PDO('sqlite:' . $path, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA foreign_keys = ON');

        self::migrate($pdo);
        self::seed($pdo, $config);

        self::$pdo = $pdo;
        return self::$pdo;
    }

    /** 测试用：重置单例（smoke 可重建） */
    public static function reset(): void
    {
        self::$pdo = null;
    }

    private static function migrate(PDO $pdo): void
    {
        $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS catalog_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    product_name TEXT NOT NULL DEFAULT '',
    product_model TEXT NOT NULL DEFAULT '',
    price_cents INTEGER NOT NULL DEFAULT 0,
    notes TEXT NOT NULL DEFAULT '',
    uploaded_by INTEGER,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    model TEXT NOT NULL DEFAULT '',
    sku TEXT NOT NULL DEFAULT '',
    price REAL NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'CNY',
    category TEXT NOT NULL DEFAULT '',
    brand TEXT NOT NULL DEFAULT '',
    series TEXT NOT NULL DEFAULT '',
    specs_json TEXT NOT NULL DEFAULT '{}',
    image_stored_name TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT 'manual',
    cut_out TEXT NOT NULL DEFAULT '',
    dimensions TEXT NOT NULL DEFAULT '',
    power TEXT NOT NULL DEFAULT '',
    power_watts REAL,
    voltage TEXT NOT NULL DEFAULT '',
    drive_current TEXT NOT NULL DEFAULT '',
    luminous_flux TEXT NOT NULL DEFAULT '',
    adjustability TEXT NOT NULL DEFAULT '',
    adaptor TEXT NOT NULL DEFAULT '',
    beam_angle TEXT NOT NULL DEFAULT '',
    cct TEXT NOT NULL DEFAULT '',
    cri TEXT NOT NULL DEFAULT '',
    ugr TEXT NOT NULL DEFAULT '',
    dimming_method TEXT NOT NULL DEFAULT '',
    ip_rating TEXT NOT NULL DEFAULT '',
    best_for TEXT NOT NULL DEFAULT '',
    catalog_page INTEGER,
    tags TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS product_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    stored_name TEXT NOT NULL,
    original_name TEXT NOT NULL DEFAULT '',
    mime TEXT NOT NULL DEFAULT '',
    is_primary INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_products_model ON products(model);
CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_products_source ON products(source);
CREATE INDEX IF NOT EXISTS idx_products_series ON products(series);
CREATE INDEX IF NOT EXISTS idx_products_tags ON products(tags);
SQL);
        self::migrateProductColumns($pdo);
        ProductParams::migrate($pdo);
        // 规格书识别记录：上传的文件、转出的页面、识别出的灯具和候选
        $pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS spec_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    original_name TEXT NOT NULL DEFAULT '',
    stored_name TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT '',
    pages_json TEXT NOT NULL DEFAULT '[]',
    items_json TEXT NOT NULL DEFAULT '[]',
    extractor TEXT NOT NULL DEFAULT '',
    seconds REAL,
    error TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_spec_runs_user ON spec_runs(user_id, id);
SQL);
    }

    /** 增量补齐灯具参数列（已有库 ALTER；新库 CREATE 已含） */
    private static function migrateProductColumns(PDO $pdo): void
    {
        $cols = [];
        foreach ($pdo->query('PRAGMA table_info(products)') as $row) {
            $cols[$row['name']] = true;
        }
        $alter = [
            'cut_out' => "TEXT NOT NULL DEFAULT ''",
            'dimensions' => "TEXT NOT NULL DEFAULT ''",
            'power' => "TEXT NOT NULL DEFAULT ''",
            'power_watts' => 'REAL',
            'voltage' => "TEXT NOT NULL DEFAULT ''",
            'drive_current' => "TEXT NOT NULL DEFAULT ''",
            'luminous_flux' => "TEXT NOT NULL DEFAULT ''",
            'adjustability' => "TEXT NOT NULL DEFAULT ''",
            'adaptor' => "TEXT NOT NULL DEFAULT ''",
            'beam_angle' => "TEXT NOT NULL DEFAULT ''",
            'cct' => "TEXT NOT NULL DEFAULT ''",
            'cri' => "TEXT NOT NULL DEFAULT ''",
            'ugr' => "TEXT NOT NULL DEFAULT ''",
            'dimming_method' => "TEXT NOT NULL DEFAULT ''",
            'ip_rating' => "TEXT NOT NULL DEFAULT ''",
            'best_for' => "TEXT NOT NULL DEFAULT ''",
            'catalog_page' => 'INTEGER',
            'tags' => "TEXT NOT NULL DEFAULT ''",
            'notes' => "TEXT NOT NULL DEFAULT ''",
        ];
        foreach ($alter as $name => $decl) {
            if (!isset($cols[$name])) {
                $pdo->exec("ALTER TABLE products ADD COLUMN {$name} {$decl}");
            }
        }
    }

    private static function seed(PDO $pdo, array $config): void
    {
        $count = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
        if ($count === 0) {
            $seed = $config['seed_admin'] ?? null;
            if ($seed) {
                $stmt = $pdo->prepare(
                    'INSERT INTO users (username, password_hash, display_name) VALUES (:u, :p, :d)'
                );
                $stmt->execute([
                    ':u' => $seed['username'],
                    ':p' => password_hash($seed['password'], PASSWORD_DEFAULT),
                    ':d' => $seed['display_name'] ?? $seed['username'],
                ]);
            }
        }

        // 独立灯具库：空表时写入 3 条与 mock 检索一致的样例
        $pCount = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
        if ($pCount === 0) {
            $samples = [
                [
                    'name' => '嵌入式筒灯 Pro',
                    'model' => 'NL-DL-75R-30W',
                    'sku' => 'NL-DL-75R-30W',
                    'price' => 128.00,
                    'category' => '筒灯',
                    'brand' => 'Novlight',
                    'series' => 'Pro',
                ],
                [
                    'name' => '磁吸轨道射灯',
                    'model' => 'NL-MS-SPOT-12W',
                    'sku' => 'NL-MS-SPOT-12W',
                    'price' => 89.50,
                    'category' => '射灯',
                    'brand' => 'Novlight',
                    'series' => '磁吸',
                ],
                [
                    'name' => '线性灯条 24V',
                    'model' => 'NL-LINE-24-3000K',
                    'sku' => 'NL-LINE-24-3000K',
                    'price' => 56.00,
                    'category' => '线性灯',
                    'brand' => 'Novlight',
                    'series' => '24V',
                ],
            ];
            $stmt = $pdo->prepare(
                'INSERT INTO products
                (name, model, sku, price, currency, category, brand, series, specs_json, image_stored_name, source)
                VALUES (:n, :m, :s, :p, :c, :cat, :b, :ser, :sp, :img, :src)'
            );
            foreach ($samples as $row) {
                $stmt->execute([
                    ':n' => $row['name'],
                    ':m' => $row['model'],
                    ':s' => $row['sku'],
                    ':p' => $row['price'],
                    ':c' => 'CNY',
                    ':cat' => $row['category'],
                    ':b' => $row['brand'],
                    ':ser' => $row['series'],
                    ':sp' => '{}',
                    ':img' => '',
                    ':src' => 'manual',
                ]);
            }
        }
    }
}
