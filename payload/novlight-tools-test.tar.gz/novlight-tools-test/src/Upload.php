<?php
declare(strict_types=1);

final class Upload
{
    /**
     * 产品图入库：仅图片。返回 ['stored_name','mime','size_bytes','original_name']。
     */
    public static function saveImage(array $file, array $config): array
    {
        $cfg = $config;
        $cfg['upload_allowed_mime'] = $config['upload_allowed_mime'] ?? ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        $cfg['upload_allowed_ext'] = $config['upload_allowed_ext'] ?? ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        $saved = self::saveFile($file, $cfg, 'image');
        $saved['kind'] = 'image';
        $saved['is_image'] = true;
        return $saved;
    }

    /**
     * 选型查询：图片 / PDF / Excel / Word / ZIP。
     * 返回含 kind、is_image、zip_members、note 等字段。
     *
     * @return array{
     *   original_name:string,stored_name:string,mime:string,size_bytes:int,
     *   kind:string,is_image:bool,ext:string,zip_members?:list<string>,note?:string,preview_image?:string
     * }
     */
    public static function saveQueryFile(array $file, array $config): array
    {
        $cfg = $config;
        $cfg['upload_allowed_mime'] = $config['query_allowed_mime'] ?? $config['upload_allowed_mime'];
        $cfg['upload_allowed_ext'] = $config['query_allowed_ext'] ?? $config['upload_allowed_ext'];
        $saved = self::saveFile($file, $cfg, 'query');

        $ext = $saved['ext'];
        $kind = self::kindFromExt($ext);
        $saved['kind'] = $kind;
        $saved['is_image'] = ($kind === 'image');

        if ($kind === 'zip') {
            $abs = $config['upload_dir'] . DIRECTORY_SEPARATOR . $saved['stored_name'];
            $zipInfo = self::inspectZip($abs, $config);
            $saved['zip_members'] = $zipInfo['members'];
            $saved['note'] = '已解析压缩包内文件列表；若含图片将尝试用于检索预览。';
            if (!empty($zipInfo['preview_image'])) {
                $saved['preview_image'] = $zipInfo['preview_image'];
            }
        } elseif (in_array($kind, ['pdf', 'excel', 'word'], true)) {
            $saved['note'] = '文档文字/内嵌图抽取为第二期能力（Phase 2），当前仅保存原文件并走模拟检索，报价流程可继续。';
        } else {
            $saved['note'] = '';
        }

        return $saved;
    }

    /**
     * @return array{original_name:string,stored_name:string,mime:string,size_bytes:int,ext:string}
     */
    private static function saveFile(array $file, array $config, string $mode): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('上传失败（错误码 ' . (int) ($file['error'] ?? -1) . '）');
        }

        $max = (int) ($config['upload_max_bytes'] ?? 50 * 1024 * 1024);
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > $max) {
            throw new RuntimeException('文件大小不符合要求（最大 ' . round($max / 1048576, 1) . 'MB）');
        }

        $tmp = $file['tmp_name'] ?? '';
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            if (!is_file($tmp)) {
                throw new RuntimeException('无效的临时文件');
            }
        }

        $orig = (string) ($file['name'] ?? 'file');
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $allowedExt = $config['upload_allowed_ext'] ?? [];
        if ($ext === '' || !in_array($ext, $allowedExt, true)) {
            throw new RuntimeException(
                $mode === 'image'
                    ? '仅支持 JPEG / PNG / WebP / GIF 图片'
                    : '仅支持图片、PDF、Excel、Word 或 ZIP（扩展名不匹配）'
            );
        }

        $mime = self::detectMime($tmp, $ext);
        $allowedMime = $config['upload_allowed_mime'] ?? [];

        // 按扩展名期望的 MIME（octet-stream 时放宽）
        $expected = self::expectedMimesForExt($ext);
        $mimeOk = in_array($mime, $allowedMime, true)
            || ($mime === 'application/octet-stream' && $expected !== [])
            || in_array($mime, $expected, true);

        if (!$mimeOk) {
            throw new RuntimeException('不支持的文件类型（MIME: ' . $mime . '）');
        }

        // 图片用 MIME 纠正扩展；其它类型保留用户扩展（已在白名单）
        if (str_starts_with($mime, 'image/')) {
            $mimeExt = match ($mime) {
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/gif' => 'gif',
                default => $ext,
            };
            if (in_array($mimeExt, $allowedExt, true)) {
                $ext = $mimeExt;
            }
        }

        $dir = $config['upload_dir'];
        if (!is_dir($dir)) {
            mkdir($dir, 0750, true);
        }
        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        $dest = $dir . DIRECTORY_SEPARATOR . $stored;
        $realDir = realpath($dir);
        if ($realDir === false) {
            throw new RuntimeException('上传目录不可用');
        }
        if (!@move_uploaded_file($tmp, $dest)) {
            if (!@rename($tmp, $dest) && !@copy($tmp, $dest)) {
                throw new RuntimeException('保存文件失败');
            }
            @unlink($tmp);
        }
        $realDest = realpath($dest);
        if ($realDest === false || strpos($realDest, $realDir) !== 0) {
            @unlink($dest);
            throw new RuntimeException('非法存储路径');
        }

        return [
            'original_name' => basename($orig),
            'stored_name' => $stored,
            'mime' => $mime,
            'size_bytes' => $size,
            'ext' => $ext,
        ];
    }

    public static function kindFromExt(string $ext): string
    {
        $ext = strtolower($ext);
        return match (true) {
            in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) => 'image',
            $ext === 'pdf' => 'pdf',
            in_array($ext, ['xls', 'xlsx'], true) => 'excel',
            in_array($ext, ['doc', 'docx'], true) => 'word',
            $ext === 'zip' => 'zip',
            default => 'other',
        };
    }

    /**
     * MIME 探测：优先 finfo；本机 PHP 若 --disable-fileinfo 则回退 mime_content_type / 扩展名。
     */
    public static function detectMime(string $path, string $ext = ''): string
    {
        if (class_exists('finfo', false)) {
            try {
                $finfo = new \finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($path);
                if (is_string($mime) && $mime !== '') {
                    return $mime;
                }
            } catch (\Throwable) {
                // fall through
            }
        }
        if (function_exists('mime_content_type')) {
            $mime = @mime_content_type($path);
            if (is_string($mime) && $mime !== '') {
                return $mime;
            }
        }
        $expected = self::expectedMimesForExt($ext);
        if ($expected !== []) {
            return $expected[0];
        }
        return 'application/octet-stream';
    }

    /** @return list<string> */
    private static function expectedMimesForExt(string $ext): array
    {
        return match (strtolower($ext)) {
            'jpg', 'jpeg' => ['image/jpeg'],
            'png' => ['image/png'],
            'webp' => ['image/webp'],
            'gif' => ['image/gif'],
            'pdf' => ['application/pdf'],
            'xls' => ['application/vnd.ms-excel', 'application/octet-stream'],
            'xlsx' => [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/zip',
                'application/octet-stream',
            ],
            'doc' => ['application/msword', 'application/octet-stream'],
            'docx' => [
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/zip',
                'application/octet-stream',
            ],
            'zip' => ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'],
            default => [],
        };
    }

    /**
     * 安全列出 ZIP 成员；若含图片则解压第一张到 uploads/tmp 供预览/检索。
     *
     * @return array{members:list<string>,preview_image:?string}
     */
    private static function inspectZip(string $zipPath, array $config): array
    {
        if (!class_exists('ZipArchive')) {
            return [
                'members' => [],
                'preview_image' => null,
                // note handled by caller if empty
            ];
        }

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new RuntimeException('无法打开 ZIP 文件');
        }

        $members = [];
        $firstImageIndex = null;
        $firstImageExt = null;
        $imageExts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if ($stat === false) {
                continue;
            }
            $name = str_replace('\\', '/', (string) $stat['name']);
            // 拒绝路径穿越与绝对路径
            if ($name === '' || str_starts_with($name, '/') || str_contains($name, '../') || str_contains($name, '..\\')) {
                $zip->close();
                throw new RuntimeException('ZIP 含非法路径，已拒绝：' . basename($name));
            }
            if (str_ends_with($name, '/')) {
                continue; // 目录项
            }
            $members[] = $name;
            $me = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if ($firstImageIndex === null && in_array($me, $imageExts, true)) {
                $firstImageIndex = $i;
                $firstImageExt = $me === 'jpeg' ? 'jpg' : $me;
            }
        }

        $previewStored = null;
        if ($firstImageIndex !== null && $firstImageExt !== null) {
            $tmpRoot = $config['upload_dir'] . DIRECTORY_SEPARATOR . 'tmp';
            if (!is_dir($tmpRoot)) {
                mkdir($tmpRoot, 0750, true);
            }
            $realUpload = realpath($config['upload_dir']);
            $content = $zip->getFromIndex($firstImageIndex);
            if ($content !== false && $realUpload !== false) {
                $previewStored = bin2hex(random_bytes(16)) . '.' . $firstImageExt;
                $dest = $config['upload_dir'] . DIRECTORY_SEPARATOR . $previewStored;
                if (@file_put_contents($dest, $content) !== false) {
                    $realDest = realpath($dest);
                    if ($realDest === false || strpos($realDest, $realUpload) !== 0) {
                        @unlink($dest);
                        $previewStored = null;
                    }
                } else {
                    $previewStored = null;
                }
            }
        }

        $zip->close();
        return [
            'members' => $members,
            'preview_image' => $previewStored,
        ];
    }
}
