<?php
declare(strict_types=1);

/**
 * 图像相似度检索。
 *
 * 默认提供商由 config image_search_provider 决定：tencent | grok | openai | mock
 * 单次检索可通过 searchSimilar(..., $providerOverride) 覆盖（会话用户自选）。
 * 腾讯云：TIAA SearchImage / CreateImage / CreateGroup（见 TencentTiiaClient）
 * 入库 indexImage 始终走腾讯（不受检索提供商覆盖影响）。
 */
final class ImageSearch
{
    private array $tencentCfg;

    /** @var array{provider?:string,request_ids?:list<string>,raw_top_score?:float|null,used_preprocess?:bool,used_dark_enhance?:bool,api_count?:int,kept?:int,threshold?:int,note?:string}|null */
    public ?array $lastSearchDebug = null;

    public function __construct(
        private array $config,
        private ?PDO $pdo = null,
    ) {
        $this->tencentCfg = $this->resolveTencentConfig();
    }

    /**
     * @param string $imagePath 本地已保存的查询图/附件绝对路径
     * @param string|null $providerOverride 会话级覆盖：tencent | grok | openai | mock；null 用配置默认
     * @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}>
     */
    public function searchSimilar(string $imagePath, int $topK = 3, ?string $providerOverride = null): array
    {
        $this->lastSearchDebug = null;
        $provider = $providerOverride ?? ($this->config['image_search_provider'] ?? 'mock');
        $provider = $this->normalizeProvider($provider);

        // 非图片查询（PDF/Office 等无预览图时）：保持 stub/mock，不调腾讯/Grok
        if (!$this->pathLooksLikeImage($imagePath)) {
            return $this->searchMock($imagePath, $topK);
        }

        return match ($provider) {
            'tencent' => $this->searchTencent($imagePath, $topK),
            'grok' => $this->searchGrok($imagePath, $topK),
            'openai' => $this->searchOpenAI($imagePath, $topK),
            default => $this->searchMock($imagePath, $topK),
        };
    }

    /** 规范化提供商标识 */
    public function normalizeProvider(string $provider): string
    {
        $provider = strtolower(trim($provider));
        return match ($provider) {
            'tencent', 'tiia', 'qq' => 'tencent',
            'grok', 'xai', 'overseas' => 'grok',
            'openai', 'open_ai' => 'openai',
            'mock', 'local' => 'mock',
            default => $provider,
        };
    }

    /** @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}> */
    private function searchMock(string $imagePath, int $topK): array
    {
        $fromDb = $this->productsFromDb($topK);
        if ($fromDb !== []) {
            return $fromDb;
        }

        $samples = [
            [
                'name' => '嵌入式筒灯 Pro',
                'model' => 'NL-DL-75R-30W',
                'price' => 128.00,
                'score' => 0.94,
                'source' => 'mock',
            ],
            [
                'name' => '磁吸轨道射灯',
                'model' => 'NL-MS-SPOT-12W',
                'price' => 89.50,
                'score' => 0.87,
                'source' => 'mock',
            ],
            [
                'name' => '线性灯条 24V',
                'model' => 'NL-LINE-24-3000K',
                'price' => 56.00,
                'score' => 0.81,
                'source' => 'mock',
            ],
        ];
        return array_slice($samples, 0, max(1, $topK));
    }

    /** @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}> */
    private function productsFromDb(int $topK): array
    {
        if (!$this->pdo instanceof PDO) {
            return [];
        }
        try {
            $limit = max(1, $topK);
            $stmt = $this->pdo->query(
                "SELECT id, name, model, price FROM products ORDER BY id ASC LIMIT {$limit}"
            );
            $rows = $stmt ? $stmt->fetchAll() : [];
        } catch (Throwable) {
            return [];
        }
        if ($rows === []) {
            return [];
        }

        $scores = [0.94, 0.87, 0.81, 0.76, 0.72];
        $out = [];
        foreach ($rows as $i => $row) {
            $out[] = [
                'name' => (string) $row['name'],
                'model' => (string) $row['model'],
                'price' => (float) $row['price'],
                'score' => $scores[$i] ?? max(0.5, 0.9 - $i * 0.05),
                'source' => 'mock-db',
                'product_id' => (int) $row['id'],
            ];
        }
        return $out;
    }

    /**
     * 腾讯云 SearchImage。
     * EntityId 约定为 p{productId}；Score 0–100 → 归一化到 0–1。
     *
     * 图库多为黑底产品图；白底查询会白→黑，近黑图会走 prepareImageForTiia 增强（与入库一致）。
     * API MatchThreshold 固定传 1（腾讯对 0 在低分场景会直接空结果），再在本地按配置阈值过滤。
     *
     * @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}>
     */
    private function searchTencent(string $imagePath, int $topK): array
    {
        $threshold = $this->matchThreshold();
        $requestIds = [];
        $usedPreprocess = false;
        $usedDarkEnhance = false;
        $bestInfos = [];
        $bestTop = -1.0;

        try {
            $client = $this->makeTiiaClient();
            $fetch = max($topK, min(20, $topK * 3));

            // 1) 原图检索（API 阈值用 1，避免 MatchThreshold=0 的空结果坑）
            $resp = $client->searchImage($imagePath, $fetch, 1, true);
            if (!empty($resp['RequestId'])) {
                $requestIds[] = (string) $resp['RequestId'];
            }
            $infos = is_array($resp['ImageInfos'] ?? null) ? $resp['ImageInfos'] : [];
            $top = $this->topScore($infos);
            if ($top > $bestTop) {
                $bestTop = $top;
                $bestInfos = $infos;
            }

            // 2) 白底图：转黑底后再搜（图库产品多为黑底棚拍）
            $preprocessed = $this->preprocessWhiteBackgroundToBlack($imagePath);
            if ($preprocessed !== null) {
                $usedPreprocess = true;
                try {
                    $resp2 = $client->searchImage($preprocessed, $fetch, 1, true);
                    if (!empty($resp2['RequestId'])) {
                        $requestIds[] = (string) $resp2['RequestId'];
                    }
                    $infos2 = is_array($resp2['ImageInfos'] ?? null) ? $resp2['ImageInfos'] : [];
                    $top2 = $this->topScore($infos2);
                    // >= so white→black wins ties over raw (aligns with black-bg library)
                    if ($top2 >= $bestTop) {
                        $bestTop = $top2;
                        $bestInfos = $infos2;
                    }
                } finally {
                    @unlink($preprocessed);
                }
            }

            // 3) 近黑棚拍：增强后再搜（与入库同一套 prepareImageForTiia）
            $darkEnhanced = $this->prepareImageForTiia($imagePath);
            if ($darkEnhanced !== null) {
                $usedDarkEnhance = true;
                try {
                    $resp3 = $client->searchImage($darkEnhanced, $fetch, 1, true);
                    if (!empty($resp3['RequestId'])) {
                        $requestIds[] = (string) $resp3['RequestId'];
                    }
                    $infos3 = is_array($resp3['ImageInfos'] ?? null) ? $resp3['ImageInfos'] : [];
                    $top3 = $this->topScore($infos3);
                    // >= so dark-enhance wins ties over raw (index uses same enhance)
                    if ($top3 >= $bestTop) {
                        $bestTop = $top3;
                        $bestInfos = $infos3;
                    }
                } finally {
                    @unlink($darkEnhanced);
                }
            }

            $out = $this->mapImageInfos($bestInfos, $threshold);
            $this->lastSearchDebug = [
                'provider' => 'tencent',
                'request_ids' => $requestIds,
                'raw_top_score' => $bestTop >= 0 ? $bestTop : null,
                'used_preprocess' => $usedPreprocess,
                'used_dark_enhance' => $usedDarkEnhance,
                'api_count' => count($bestInfos),
                'kept' => count($out),
                'threshold' => $threshold,
                'group_id' => $this->tencentCfg['group_id'] ?? '',
            ];

            if ($out === []) {
                return [];
            }
            return array_slice($out, 0, max(1, $topK));
        } catch (Throwable $ex) {
            $this->lastSearchDebug = [
                'provider' => 'tencent',
                'request_ids' => $requestIds,
                'raw_top_score' => $bestTop >= 0 ? $bestTop : null,
                'used_preprocess' => $usedPreprocess,
                'used_dark_enhance' => $usedDarkEnhance,
                'threshold' => $threshold,
                'note' => $ex->getMessage(),
            ];
            if ($this->fallbackMockEnabled()) {
                return $this->searchMock($imagePath, $topK);
            }
            throw new RuntimeException(
                $ex->getMessage() !== '' ? $ex->getMessage() : '腾讯云图像搜索失败',
                0,
                $ex instanceof Exception ? $ex : null
            );
        }
    }

    /** @param list<array> $infos */
    private function topScore(array $infos): float
    {
        $best = -1.0;
        foreach ($infos as $info) {
            if (!is_array($info)) {
                continue;
            }
            $s = (float) ($info['Score'] ?? -1);
            if ($s > $best) {
                $best = $s;
            }
        }
        return $best;
    }

    /**
     * @param list<array> $infos
     * @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}>
     */
    private function mapImageInfos(array $infos, int $threshold): array
    {
        $out = [];
        foreach ($infos as $info) {
            if (!is_array($info)) {
                continue;
            }
            $entityId = (string) ($info['EntityId'] ?? '');
            $picName = (string) ($info['PicName'] ?? '');
            $score100 = (float) ($info['Score'] ?? 0);
            if ($score100 < $threshold) {
                continue;
            }
            $score = max(0.0, min(1.0, $score100 / 100.0));
            $productId = $this->parseProductId($entityId, $picName);
            $mapped = $productId !== null ? $this->productById($productId) : null;
            if ($mapped === null) {
                // EntityId 对不上 DB：跳过，避免展示未知/错位
                continue;
            }
            $out[] = [
                'name' => $mapped['name'],
                'model' => $mapped['model'],
                'price' => $mapped['price'],
                'score' => $score,
                'source' => 'tencent',
                'product_id' => $mapped['id'],
            ];
        }
        return $out;
    }

    /**
     * 检测四角接近纯白时，把近白像素换成黑底，写出临时 JPEG。
     * 非白底返回 null（不预处理）。
     */
    private function preprocessWhiteBackgroundToBlack(string $imagePath): ?string
    {
        if (!function_exists('imagecreatetruecolor')) {
            return null;
        }
        $info = @getimagesize($imagePath);
        if ($info === false) {
            return null;
        }
        $im = match ((int) ($info[2] ?? 0)) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($imagePath),
            IMAGETYPE_PNG => @imagecreatefrompng($imagePath),
            IMAGETYPE_GIF => @imagecreatefromgif($imagePath),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($imagePath) : false,
            default => false,
        };
        if ($im === false) {
            return null;
        }

        $w = imagesx($im);
        $h = imagesy($im);
        if ($w < 8 || $h < 8) {
            imagedestroy($im);
            return null;
        }

        $pts = [[2, 2], [$w - 3, 2], [2, $h - 3], [$w - 3, $h - 3]];
        $sum = 0.0;
        foreach ($pts as [$x, $y]) {
            $rgb = imagecolorat($im, $x, $y);
            $r = ($rgb >> 16) & 255;
            $g = ($rgb >> 8) & 255;
            $b = $rgb & 255;
            $sum += ($r + $g + $b) / 3.0;
        }
        $cornerAvg = $sum / count($pts);
        // 非白底：不处理（避免伤黑底棚拍）
        if ($cornerAvg < 245.0) {
            imagedestroy($im);
            return null;
        }

        $out = imagecreatetruecolor($w, $h);
        if ($out === false) {
            imagedestroy($im);
            return null;
        }
        $black = imagecolorallocate($out, 0, 0, 0);
        // 仅替换接近纯白的背景；阈值偏高，保留产品高光
        for ($y = 0; $y < $h; $y++) {
            for ($x = 0; $x < $w; $x++) {
                $rgb = imagecolorat($im, $x, $y);
                $r = ($rgb >> 16) & 255;
                $g = ($rgb >> 8) & 255;
                $b = $rgb & 255;
                if ($r > 248 && $g > 248 && $b > 248) {
                    imagesetpixel($out, $x, $y, $black);
                } else {
                    imagesetpixel($out, $x, $y, imagecolorallocate($out, $r, $g, $b));
                }
            }
        }
        imagedestroy($im);

        $tmp = sys_get_temp_dir() . '/nl_tiia_' . bin2hex(random_bytes(8)) . '.jpg';
        $ok = imagejpeg($out, $tmp, 92);
        imagedestroy($out);
        if (!$ok || !is_readable($tmp)) {
            @unlink($tmp);
            return null;
        }
        return $tmp;
    }

    /**
     * 近黑产品图增强：裁非黑 bbox → 置于 #303030 画布（最短边≥512）→ 亮度+25、轻度对比。
     * 非近黑返回 null。入库与检索共用，保证特征对齐。
     */
    private function prepareImageForTiia(string $imagePath): ?string
    {
        if (!function_exists('imagecreatetruecolor')) {
            return null;
        }
        $info = @getimagesize($imagePath);
        if ($info === false) {
            return null;
        }
        $im = match ((int) ($info[2] ?? 0)) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($imagePath),
            IMAGETYPE_PNG => @imagecreatefrompng($imagePath),
            IMAGETYPE_GIF => @imagecreatefromgif($imagePath),
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($imagePath) : false,
            default => false,
        };
        if ($im === false) {
            return null;
        }

        $w = imagesx($im);
        $h = imagesy($im);
        if ($w < 8 || $h < 8) {
            imagedestroy($im);
            return null;
        }

        $pts = [[2, 2], [$w - 3, 2], [2, $h - 3], [$w - 3, $h - 3]];
        $cornerSum = 0.0;
        foreach ($pts as [$x, $y]) {
            $rgb = imagecolorat($im, $x, $y);
            $r = ($rgb >> 16) & 255;
            $g = ($rgb >> 8) & 255;
            $b = $rgb & 255;
            $cornerSum += ($r + $g + $b) / 3.0;
        }
        $cornerAvg = $cornerSum / count($pts);

        // 抽样估算非黑像素占比（lum > 15）
        $stepX = max(1, (int) floor($w / 80));
        $stepY = max(1, (int) floor($h / 80));
        $sampled = 0;
        $nonBlack = 0;
        $minX = $w;
        $minY = $h;
        $maxX = -1;
        $maxY = -1;
        for ($y = 0; $y < $h; $y += $stepY) {
            for ($x = 0; $x < $w; $x += $stepX) {
                $rgb = imagecolorat($im, $x, $y);
                $r = ($rgb >> 16) & 255;
                $g = ($rgb >> 8) & 255;
                $b = $rgb & 255;
                $lum = ($r + $g + $b) / 3.0;
                $sampled++;
                if ($lum > 15.0) {
                    $nonBlack++;
                    if ($x < $minX) {
                        $minX = $x;
                    }
                    if ($y < $minY) {
                        $minY = $y;
                    }
                    if ($x > $maxX) {
                        $maxX = $x;
                    }
                    if ($y > $maxY) {
                        $maxY = $y;
                    }
                }
            }
        }
        $nonBlackRatio = $sampled > 0 ? ($nonBlack / $sampled) : 1.0;

        // 非近黑：不处理
        if ($nonBlackRatio >= 0.08 && $cornerAvg >= 20.0) {
            imagedestroy($im);
            return null;
        }
        if ($maxX < $minX || $maxY < $minY) {
            imagedestroy($im);
            return null;
        }

        // 精扫 bbox（在粗 bbox 邻域）
        $padScan = max(4, (int) max($stepX, $stepY) * 2);
        $scanMinX = max(0, $minX - $padScan);
        $scanMinY = max(0, $minY - $padScan);
        $scanMaxX = min($w - 1, $maxX + $padScan);
        $scanMaxY = min($h - 1, $maxY + $padScan);
        $minX = $w;
        $minY = $h;
        $maxX = -1;
        $maxY = -1;
        for ($y = $scanMinY; $y <= $scanMaxY; $y++) {
            for ($x = $scanMinX; $x <= $scanMaxX; $x++) {
                $rgb = imagecolorat($im, $x, $y);
                $r = ($rgb >> 16) & 255;
                $g = ($rgb >> 8) & 255;
                $b = $rgb & 255;
                if (($r + $g + $b) / 3.0 > 15.0) {
                    if ($x < $minX) {
                        $minX = $x;
                    }
                    if ($y < $minY) {
                        $minY = $y;
                    }
                    if ($x > $maxX) {
                        $maxX = $x;
                    }
                    if ($y > $maxY) {
                        $maxY = $y;
                    }
                }
            }
        }
        if ($maxX < $minX || $maxY < $minY) {
            imagedestroy($im);
            return null;
        }

        $pad = (int) max(8, round(max($maxX - $minX + 1, $maxY - $minY + 1) * 0.08));
        $minX = max(0, $minX - $pad);
        $minY = max(0, $minY - $pad);
        $maxX = min($w - 1, $maxX + $pad);
        $maxY = min($h - 1, $maxY + $pad);
        $cw = $maxX - $minX + 1;
        $ch = $maxY - $minY + 1;

        $crop = imagecreatetruecolor($cw, $ch);
        if ($crop === false) {
            imagedestroy($im);
            return null;
        }
        imagecopy($crop, $im, 0, 0, $minX, $minY, $cw, $ch);
        imagedestroy($im);

        // 亮度 +25，轻度对比（GD contrast 负值=更强对比）
        imagefilter($crop, IMG_FILTER_BRIGHTNESS, 25);
        imagefilter($crop, IMG_FILTER_CONTRAST, -12);

        // 过大裁切缩到最长边 ≤1024，避免 GD 画布撑爆内存
        $maxSide = 1024;
        $srcW = $cw;
        $srcH = $ch;
        if (max($cw, $ch) > $maxSide) {
            $scale = $maxSide / max($cw, $ch);
            $nw = max(1, (int) round($cw * $scale));
            $nh = max(1, (int) round($ch * $scale));
            $scaled = imagecreatetruecolor($nw, $nh);
            if ($scaled === false) {
                imagedestroy($crop);
                return null;
            }
            imagecopyresampled($scaled, $crop, 0, 0, 0, 0, $nw, $nh, $cw, $ch);
            imagedestroy($crop);
            $crop = $scaled;
            $cw = $nw;
            $ch = $nh;
        }

        $margin = (int) max(24, round(max($cw, $ch) * 0.12));
        $canvasW = max(512, min(1280, $cw + $margin * 2));
        $canvasH = max(512, min(1280, $ch + $margin * 2));
        // 保证画布能放下内容
        $canvasW = max($canvasW, $cw + 8);
        $canvasH = max($canvasH, $ch + 8);
        $canvas = imagecreatetruecolor($canvasW, $canvasH);
        if ($canvas === false) {
            imagedestroy($crop);
            return null;
        }
        $gray = imagecolorallocate($canvas, 0x30, 0x30, 0x30);
        imagefilledrectangle($canvas, 0, 0, $canvasW, $canvasH, $gray);
        $dstX = (int) (($canvasW - $cw) / 2);
        $dstY = (int) (($canvasH - $ch) / 2);
        imagecopy($canvas, $crop, $dstX, $dstY, 0, 0, $cw, $ch);
        imagedestroy($crop);

        $tmp = sys_get_temp_dir() . '/nl_tiia_dark_' . bin2hex(random_bytes(8)) . '.jpg';
        $ok = imagejpeg($canvas, $tmp, 92);
        imagedestroy($canvas);
        if (!$ok || !is_readable($tmp)) {
            @unlink($tmp);
            return null;
        }
        return $tmp;
    }

    /** 腾讯 MatchThreshold 0–100（本地过滤用） */
    private function matchThreshold(): int
    {
        $v = (int) ($this->config['image_search']['match_threshold'] ?? 60);
        return max(0, min(100, $v));
    }

    /**
     * Grok（海外）识图：尚未接入，明确提示，不伪造匹配结果。
     *
     * @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}>
     */
    private function searchGrok(string $imagePath, int $topK): array
    {
        throw new RuntimeException('Grok 识图即将接入');
    }

    /** @return list<array{name:string,model:string,price:float,score:float,source:string,product_id?:int}> */
    private function searchOpenAI(string $imagePath, int $topK): array
    {
        return $this->searchMock($imagePath, $topK);
    }

    /**
     * 产品图入库提特征：腾讯 CreateImage。
     * EntityId = p{productId}，PicName = p{productId}_main，
     * CustomContent = JSON{name,model,price}
     *
     * @param array{product_id?:int|string,product_name?:string,product_model?:string,price?:float|int|string,name?:string,model?:string} $meta
     */
    public function indexImage(string $imagePath, array $meta = []): bool
    {
        $provider = $this->normalizeProvider((string) ($this->config['image_search_provider'] ?? 'tencent'));
        $hasSecrets = ($this->tencentCfg['secret_id'] ?? '') !== '' && ($this->tencentCfg['secret_key'] ?? '') !== '';
        if ($provider === 'mock' || !$hasSecrets) {
            return true;
        }

        $productId = (int) ($meta['product_id'] ?? 0);
        if ($productId <= 0) {
            throw new RuntimeException('indexImage 需要 meta.product_id');
        }
        if (!$this->pathLooksLikeImage($imagePath) || !is_readable($imagePath)) {
            throw new RuntimeException('入库图片不可读或不是图片文件');
        }

        $name = (string) ($meta['product_name'] ?? $meta['name'] ?? '');
        $model = (string) ($meta['product_model'] ?? $meta['model'] ?? '');
        $price = (float) ($meta['price'] ?? 0);
        $forceReindex = !empty($meta['force_reindex']);

        $entityId = 'p' . $productId;
        $picName = $entityId . '_main';
        $custom = json_encode(
            ['name' => $name, 'model' => $model, 'price' => $price],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ) ?: '{}';

        $uploadPath = $imagePath;
        $tempEnhanced = $this->prepareImageForTiia($imagePath);
        if ($tempEnhanced !== null) {
            $uploadPath = $tempEnhanced;
        }

        try {
            $client = $this->makeTiiaClient();
            $client->createGroupIfNeeded();

            $doCreate = function () use ($client, $entityId, $picName, $uploadPath, $custom): void {
                $client->createImage($entityId, $picName, null, $uploadPath, $custom);
            };

            if ($forceReindex) {
                try {
                    $client->deleteImages($entityId, $picName);
                } catch (Throwable) {
                    // 不存在时可忽略
                }
                usleep(150000);
                $doCreate();
                return true;
            }

            try {
                $doCreate();
                return true;
            } catch (Throwable $ex) {
                $msg = $ex->getMessage();
                if (
                    str_contains($msg, 'PicNameAlreadyExist')
                    || str_contains($msg, 'EntityIdAlreadyExist')
                    || str_contains($msg, 'ImageAlreadyExist')
                    || str_contains($msg, 'AlreadyExist')
                ) {
                    try {
                        $client->deleteImages($entityId, $picName);
                    } catch (Throwable) {
                        // ignore
                    }
                    usleep(150000);
                    $doCreate();
                    return true;
                }
                throw $ex;
            }
        } catch (Throwable $ex) {
            $msg = $ex->getMessage();
            if ($this->fallbackMockEnabled()) {
                return false;
            }
            throw new RuntimeException(
                $msg !== '' ? $msg : '腾讯云 CreateImage 失败',
                0,
                $ex instanceof Exception ? $ex : null
            );
        } finally {
            if ($tempEnhanced !== null) {
                @unlink($tempEnhanced);
            }
        }
    }

    private function makeTiiaClient(): TencentTiiaClient
    {
        return new TencentTiiaClient($this->tencentCfg);
    }

    private function resolveTencentConfig(): array
    {
        $base = $this->config['image_search']['tencent'] ?? [];
        if (!is_array($base)) {
            $base = [];
        }

        $secretId = (string) ($base['secret_id'] ?? '');
        $secretKey = (string) ($base['secret_key'] ?? '');

        $secretsFile = (string) ($this->config['tencent_secrets_file']
            ?? ($base['secrets_file'] ?? ''));

        if (($secretId === '' || $secretKey === '') && $secretsFile !== '' && is_readable($secretsFile)) {
            $loaded = include $secretsFile;
            if (is_array($loaded)) {
                if ($secretId === '' && !empty($loaded['secret_id'])) {
                    $secretId = (string) $loaded['secret_id'];
                }
                if ($secretKey === '' && !empty($loaded['secret_key'])) {
                    $secretKey = (string) $loaded['secret_key'];
                }
                if (empty($base['region']) && !empty($loaded['region'])) {
                    $base['region'] = (string) $loaded['region'];
                }
            }
        }

        return [
            'secret_id' => $secretId,
            'secret_key' => $secretKey,
            'region' => (string) ($base['region'] ?? 'ap-guangzhou'),
            'group_id' => (string) ($base['group_id'] ?? 'novlight_lighting'),
            'group_type' => (int) ($base['group_type'] ?? 4),
            'max_capacity' => (int) ($base['max_capacity'] ?? 10000),
        ];
    }

    private function fallbackMockEnabled(): bool
    {
        $v = $this->config['image_search']['fallback_mock'] ?? true;
        return (bool) $v;
    }

    private function pathLooksLikeImage(string $path): bool
    {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        return in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'], true);
    }

    private function parseProductId(string $entityId, string $picName): ?int
    {
        foreach ([$entityId, $picName] as $s) {
            if (preg_match('/^p(\d+)/', $s, $m)) {
                return (int) $m[1];
            }
        }
        return null;
    }

    /** @return array{id:int,name:string,model:string,price:float}|null */
    private function productById(int $id): ?array
    {
        if (!$this->pdo instanceof PDO || $id <= 0) {
            return null;
        }
        try {
            $stmt = $this->pdo->prepare('SELECT id, name, model, price FROM products WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) {
                return null;
            }
            return [
                'id' => (int) $row['id'],
                'name' => (string) $row['name'],
                'model' => (string) $row['model'],
                'price' => (float) $row['price'],
            ];
        } catch (Throwable) {
            return null;
        }
    }
}
