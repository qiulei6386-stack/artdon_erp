# Novlight 工具台（自动选型系统）

桌面端优先的 PHP 网页工具：登录 → 功能菜单 → **自动选型系统** / **产品图入库**。

界面语言：简体中文。无前端构建步骤（纯 PHP + CSS + 少量 JS）。

## 本地运行

```bash
cd /workspace/novlight-tools
php -S localhost:8080 -t public
```

浏览器打开：http://localhost:8080/

### 默认账号

| 用户名 | 密码 |
|--------|------|
| `admin` | `ChangeMe123!` |

首次启动会自动在 `data/app.sqlite` 建表并写入管理员与 **3 条样例灯具**。请尽快改密。

### 冒烟检查

```bash
php scripts/smoke.php
```

## 使用流程

1. **登录** → **功能菜单**。
2. **自动选型系统**：拖入或选择查询文件（图片 / PDF / Excel / Word / ZIP，最大 50MB）→ 查看相似产品（当前模拟，优先读灯具库）→ 勾选生成报价摘要。
   - 图片：预览并检索。
   - ZIP：安全列出成员；若含图片则解出首张作预览。
   - PDF / Office：原文件保存；文字/内嵌图抽取为第二期（Phase 2），仍走模拟检索以便报价。
3. **产品图入库**：产品图写入独立 **灯具库**（SQLite `products`，与 ERP 分离），可填品类/品牌/系列。
4. **退出**：顶栏「退出」。

## 独立灯具库

与 `artdon_erp` 无关的本地选型库：

| 表 | 说明 |
|----|------|
| `products` | 名称、型号/SKU、价格、币种、品类、品牌、系列、`specs_json`、主图、来源（manual\|import） |
| `product_images` | 副图（可选） |
| `users` | 登录账号 |

模拟检索优先读 `products`；表空时回退硬编码样例。

## 目录结构

```
novlight-tools/
├── public/           # Web 根（index.php + assets）
├── src/              # Auth / Database / Csrf / Upload / ImageSearch
├── templates/
├── data/             # SQLite + uploads（勿直接公网暴露）
├── config.php
├── scripts/smoke.php
└── README.md
```

## 部署到 novlight.com

文档根 `/www/wwwroot/Artdon/`：**保留** `artdon_erp/`。推荐整包在 `/www/wwwroot/novlight-tools/`，仅同步 `public/` 到站点根。本仓库不负责 SSH。

## 安全要点

- 密码：`password_hash` / `password_verify`；POST CSRF；Session HttpOnly
- 上传：白名单扩展名 + MIME；随机文件名；ZIP 拒绝路径穿越
- 非图片查询文件仅登录后可下载（`Content-Disposition: attachment`）

## 图像 API（待办）

`image_search_provider`：`mock`（默认）| `tencent` | `openai`。详见 `src/ImageSearch.php` TODO。

## 服务器上的位置（2026-10-17 存档时）

- 程序目录：`/www/wwwroot/novlight-tools/`（本仓库根目录，`config.php`、`data/app.sqlite`、`data/uploads/` 只在服务器上，不进仓库）
- 网站根目录：`/www/wwwroot/Artdon/`（novlight.com）。其中 `index.php` 是 `public/index.php` 的副本，开头改为 `require '/www/wwwroot/novlight-tools/src/bootstrap.php'`；`assets/` 与 `public/assets/` 相同。线上这份副本存档在 `deploy/site-root/`。
- 腾讯云密钥：`/www/server/artdon_secrets/tencent_ocr.php`（不进仓库）

## 规格书参数匹配（2026-10 新增）

客户发来的规格书（多页 PDF、Word、Excel、ZIP 或图片）→ 每页转成图片 → 通义千问 VL（`qwen-vl-max`）读出每款灯的类型、开孔、尺寸、功率、光通量、调角、光束角、色温、显指、UGR、IP、调光 → 按参数在产品库里打分，每款给出 5 个最接近的型号、匹配点和差异 → 选型号、填数量 → 报价摘要 / 下载 CSV。

- 代码：`src/SpecDocument.php`（文件转页面图）、`src/SpecExtractor.php`（调识图模型）、`src/SpecMatcher.php`（打分）、`src/SpecRun.php`（流程和报价）、`src/ProductParams.php`（产品文字参数 → 数字列）、`templates/spec_result.php`
- 数据库：启动时自动给 `products` 加数字列（`type_key`、`cutout_mm`、`tilt_deg` 等）并从现有文字参数算一遍；新建表 `spec_runs` 存每次识别。原有列和数据不动。
- 打分：只比双方都有的参数，得分 = 得到的分 ÷ 可得的分。开孔比对方大（原孔装不下）不得分；筒灯 / 射灯算近似同类；导轨灯和嵌入式灯互不匹配。
- 测试：`php tests/run.php`（离线，用 `tests/fixtures/sail_spec.json` 验证 Pluxb SAIL 首选 LITE 52.04538）

### 上线步骤（在服务器上执行，先备份）

```bash
# 0. 备份
cd /www/wwwroot
tar czf /root/novlight_backup_$(date +%Y%m%d_%H%M).tgz novlight-tools Artdon/index.php Artdon/assets Artdon/.user.ini

# 1. 系统工具（PDF 转图片；Word/Excel 转 PDF 可选）
yum install -y poppler-utils libreoffice-headless   # Debian/Ubuntu: apt install poppler-utils libreoffice-core

# 2. 识图密钥（二选一）
#   通义千问：阿里云百炼控制台申请 API Key → dashscope.php，config 里 'provider' => 'qwen'
#   腾讯混元：腾讯云混元控制台「API Key」页创建 → hunyuan.php，config 里 'provider' => 'hunyuan'
#   （注意：现有的腾讯 SecretId/SecretKey 不能直接用，混元要单独创建 API Key）
cat > /www/server/artdon_secrets/hunyuan.php <<'PHP'
<?php return ['api_key' => '在这里填'];
PHP
chmod 640 /www/server/artdon_secrets/hunyuan.php; chown root:www /www/server/artdon_secrets/hunyuan.php

# 3. 更新程序目录（config.php、data/ 不在仓库里，不会被覆盖）
cd /www/wwwroot/novlight-tools && git pull     # 首次：git clone 到新目录后把旧的 config.php 和 data/ 拷进去

# 4. config.php 末尾加上 config.example.php 里的 'spec' => [...] 一段

# 5. 网站入口换成转发文件，并更新样式脚本
cp deploy/site-root/index.php deploy/site-root/.user.ini /www/wwwroot/Artdon/
cp -r deploy/site-root/assets/* /www/wwwroot/Artdon/assets/

# 6. 用目录核对过的参数校正产品库（先看预览，再写入）
php scripts/sync_catalog_params.php
php scripts/sync_catalog_params.php --apply
```

宝塔里 Nginx 的 `fastcgi_read_timeout` 如果是默认 60 秒，多页规格书可能超时，建议改为 300。
