(function () {
  // 报价表单：至少勾选一项
  var form = document.getElementById('quote-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      var checked = form.querySelectorAll('input[name="selected[]"]:checked');
      if (!checked.length) {
        e.preventDefault();
        alert('请至少勾选一个产品再生成报价');
      }
    });
  }

  // 提交后按钮显示“处理中”，防止重复提交
  document.querySelectorAll('button[data-busy-text]').forEach(function (btn) {
    var f = btn.form;
    if (!f) return;
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      btn.textContent = btn.getAttribute('data-busy-text');
      setTimeout(function () { btn.disabled = true; }, 0);
    });
  });

  // 选型：拖放上传区
  var zone = document.getElementById('query-dropzone');
  var input = document.getElementById('query-file-input');
  var nameEl = document.getElementById('query-file-name');
  if (!zone || !input) return;

  function setFileName(file) {
    if (!nameEl) return;
    if (!file) {
      nameEl.textContent = '尚未选择文件';
      return;
    }
    var mb = (file.size / (1024 * 1024)).toFixed(2);
    nameEl.textContent = '已选择：' + file.name + '（' + mb + ' MB）';
  }

  function assignFile(file) {
    if (!file) return;
    try {
      var dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
    } catch (err) {
      console.warn(err);
    }
    setFileName(file);
    zone.classList.add('has-file');
  }

  zone.addEventListener('click', function (e) {
    if (e.target === input) return;
    input.click();
  });

  zone.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      input.click();
    }
  });

  input.addEventListener('change', function () {
    var f = input.files && input.files[0] ? input.files[0] : null;
    setFileName(f);
    if (f) zone.classList.add('has-file');
    else zone.classList.remove('has-file');
  });

  function onDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    zone.classList.add('is-dragover');
  }

  function onDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    // 仅当离开整个 dropzone 时去掉高亮
    if (!zone.contains(e.relatedTarget)) {
      zone.classList.remove('is-dragover');
    }
  }

  function onDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    zone.classList.remove('is-dragover');
    var files = e.dataTransfer && e.dataTransfer.files;
    if (!files || !files.length) return;
    assignFile(files[0]);
  }

  ['dragenter', 'dragover'].forEach(function (ev) {
    zone.addEventListener(ev, onDragOver);
    input.addEventListener(ev, onDragOver);
  });
  zone.addEventListener('dragleave', onDragLeave);
  input.addEventListener('dragleave', onDragLeave);
  zone.addEventListener('drop', onDrop);
  input.addEventListener('drop', onDrop);

  // 阻止浏览器在页面其它区域直接打开拖入的文件
  ['dragover', 'drop'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (zone.contains(e.target)) return;
      e.preventDefault();
    });
  });
})();
