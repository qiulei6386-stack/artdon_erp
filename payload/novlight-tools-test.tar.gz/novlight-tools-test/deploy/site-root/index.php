<?php
// novlight.com 网站入口：只转到程序目录里的 public/index.php，
// 以后程序更新只要更新 /www/wwwroot/novlight-tools，这个文件不用再改。
require '/www/wwwroot/novlight-tools/public/index.php';
