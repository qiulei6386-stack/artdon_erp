#!/bin/bash
# 在服务器上装一个“测试版”选型系统，和现在的网站完全分开：
#   程序：/www/wwwroot/novlight-tools-test/      （本压缩包解开的目录）
#   入口：https://novlight.com/spectest/index.php
#   数据：复制一份现在的产品库和产品图片，测试时怎么改都不影响正式网站
#
# 用法（在解开后的目录里）：
#   bash deploy/install_test.sh hunyuan 你的APIKey      # 腾讯混元
#   bash deploy/install_test.sh qwen    你的APIKey      # 通义千问
set -euo pipefail

PROVIDER="${1:-}"
KEY="${2:-}"
LIVE=/www/wwwroot/novlight-tools
SITE=/www/wwwroot/Artdon
SECRETS=/www/server/artdon_secrets
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TARGET=/www/wwwroot/novlight-tools-test

if [[ "$PROVIDER" != "hunyuan" && "$PROVIDER" != "qwen" ]] || [[ -z "$KEY" ]]; then
  echo "用法：bash deploy/install_test.sh hunyuan|qwen 你的APIKey"; exit 1
fi
if [[ "$HERE" != "$TARGET" ]]; then
  echo "请把程序解压到 $TARGET 再运行（现在在 $HERE）"; exit 1
fi
[[ -f "$LIVE/config.php" && -f "$LIVE/data/app.sqlite" ]] || { echo "找不到正式网站的 $LIVE/config.php 或数据库"; exit 1; }

PHP_BIN="$(command -v php || true)"
[[ -z "$PHP_BIN" ]] && PHP_BIN="$(ls -d /www/server/php/8*/bin/php 2>/dev/null | tail -1)"
[[ -x "$PHP_BIN" ]] || { echo "找不到 php 命令"; exit 1; }

echo "1/5 检查 PDF 转图片工具"
if ! command -v pdftoppm >/dev/null; then
  (command -v yum >/dev/null && yum install -y poppler-utils) || (command -v apt-get >/dev/null && apt-get install -y poppler-utils) || echo "  ！没装上 poppler-utils，PDF 会改用 Imagick（如果有）"
fi
command -v pdftoppm >/dev/null && echo "  pdftoppm 可用"

echo "2/5 复制产品库和图片（只复制，不改正式数据）"
mkdir -p "$TARGET/data"
cp -a "$LIVE/data/app.sqlite" "$TARGET/data/app.sqlite"
rm -rf "$TARGET/data/uploads"
cp -a "$LIVE/data/uploads" "$TARGET/data/uploads"

echo "3/5 写配置和密钥"
cat > "$TARGET/config.php" <<PHP
<?php
// 测试版配置：沿用正式网站的配置，只换数据位置、登录 cookie 名和识图模型
\$c = require '$LIVE/config.php';
\$c['db_path'] = __DIR__ . '/data/app.sqlite';
\$c['upload_dir'] = __DIR__ . '/data/uploads';
\$c['session_name'] = 'novlight_spectest_sess';
\$c['spec'] = ['provider' => '$PROVIDER', 'pages_per_request' => 2, 'candidates' => 5];
return \$c;
PHP
mkdir -p "$SECRETS"
FILE="$SECRETS/$([[ $PROVIDER == qwen ]] && echo dashscope || echo hunyuan).php"
printf "<?php return ['api_key' => '%s'];\n" "$KEY" > "$FILE"
if chown "$(id -u)":www "$FILE" 2>/dev/null; then chmod 640 "$FILE"; else chmod 644 "$FILE"; fi

echo "4/5 开测试入口 $SITE/spectest/"
mkdir -p "$SITE/spectest"
printf "<?php\nrequire '%s/public/index.php';\n" "$TARGET" > "$SITE/spectest/index.php"
rm -rf "$SITE/spectest/assets"
cp -a "$TARGET/public/assets" "$SITE/spectest/assets"
cp -a "$TARGET/public/.user.ini" "$SITE/spectest/.user.ini" 2>/dev/null || true
chown -R www:www "$TARGET/data" "$SITE/spectest" 2>/dev/null || true

echo "5/5 在测试库上校正产品参数，并跑离线测试"
"$PHP_BIN" "$TARGET/scripts/sync_catalog_params.php" --apply | tail -2
chown www:www "$TARGET/data/app.sqlite" 2>/dev/null || true
"$PHP_BIN" "$TARGET/tests/run.php" | tail -1

echo
echo "装好了。打开 https://novlight.com/spectest/index.php 用原来的账号登录测试。"
echo "正式网站没有任何改动。不要测试版时：rm -rf $SITE/spectest $TARGET"
