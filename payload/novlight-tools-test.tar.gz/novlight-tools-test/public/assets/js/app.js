(function () {
  // 报价表单：至少勾选一项
  var form = document.getElementById('quote-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      var checked = form.querySelectorAll('input[name="selected[]"]:checked');
      if (!checked.length) {
        e.preventDefault();
        alert('请至少勾选一个产品再生成报价');
      }
    });
  }

  // 提交后按钮显示“处理中”，防止重复提交
  document.querySelectorAll('button[data-busy-text]').forEach(function (btn) {
    var f = btn.form;
    if (!f) return;
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      btn.textContent = btn.getAttribute('data-busy-text');
      setTimeout(function () { btn.disabled = true; }, 0);
    });
  });

  // 规格书：PDF 先在浏览器里逐页转成图片再上传（服务器不需要 PDF 工具）
  var specForm = document.getElementById('selection-upload-form');
  if (specForm && window.fetch && window.FormData) {
    var MAX_PAGES = 20;
    var loadPdfJs = function () {
      if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
      return new Promise(function (resolve, reject) {
        var s = document.createElement('script');
        s.src = 'assets/vendor/pdfjs/pdf.js';
        s.onload = function () {
          window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'assets/vendor/pdfjs/pdf.worker.js';
          resolve(window.pdfjsLib);
        };
        s.onerror = function () { reject(new Error('PDF 组件加载失败')); };
        document.head.appendChild(s);
      });
    };
    var canvasToBlob = function (canvas) {
      return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', 0.85); });
    };
    var renderPdf = function (file, onProgress) {
      return loadPdfJs().then(function (pdfjsLib) {
        return file.arrayBuffer().then(function (buf) {
          return pdfjsLib.getDocument({ data: buf }).promise;
        });
      }).then(function (pdf) {
        var n = Math.min(pdf.numPages, MAX_PAGES);
        var pages = [];
        var texts = [];
        var chain = Promise.resolve();
        for (var i = 1; i <= n; i++) {
          (function (no) {
            chain = chain.then(function () {
              onProgress(no, n);
              return pdf.getPage(no).then(function (page) {
                var base = page.getViewport({ scale: 1 });
                var scale = Math.min(3, 1600 / Math.max(base.width, base.height));
                var vp = page.getViewport({ scale: scale });
                var canvas = document.createElement('canvas');
                canvas.width = Math.round(vp.width);
                canvas.height = Math.round(vp.height);
                var ctx = canvas.getContext('2d');
                ctx.fillStyle = '#fff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                return page.render({ canvasContext: ctx, viewport: vp }).promise
                  .then(function () { return canvasToBlob(canvas); })
                  .then(function (blob) { if (blob) pages.push(blob); })
                  .then(function () { return page.getTextContent(); })
                  .then(function (tc) {
                    var t = tc.items.map(function (it) { return it.str + (it.hasEOL ? '\n' : ' '); }).join('');
                    if (t.trim()) texts.push('--- 第 ' + no + ' 页 ---\n' + t);
                  });
              });
            });
          })(i);
        }
        return chain.then(function () { return { pages: pages, text: texts.join('\n'), total: pdf.numPages }; });
      });
    };

    specForm.addEventListener('submit', function (e) {
      var mode = specForm.querySelector('input[name="image_search_provider"]:checked');
      var input = document.getElementById('query-file-input');
      var file = input && input.files && input.files[0];
      if (!mode || mode.value !== 'spec' || !file || !/\.pdf$/i.test(file.name) || specForm.dataset.rendered === '1') return;
      e.preventDefault();
      var btn = document.getElementById('btn-search');
      var say = function (t) { if (btn) btn.textContent = t; };
      renderPdf(file, function (no, n) { say('正在转换第 ' + no + ' / ' + n + ' 页…'); })
        .then(function (r) {
          say('正在识别，请稍候…（' + r.pages.length + ' 页，约需 20～60 秒）');
          var fd = new FormData(specForm);
          r.pages.forEach(function (b, i) { fd.append('spec_pages[]', b, 'p-' + (i + 1) + '.jpg'); });
          fd.append('spec_text', r.text);
          return fetch(specForm.getAttribute('action'), { method: 'POST', body: fd, credentials: 'same-origin' });
        })
        .then(function (resp) {
          window.location.href = resp.url || 'index.php?r=selection';
        })
        .catch(function (err) {
          console.warn(err);
          // 转换失败就按原方式上传
          specForm.dataset.rendered = '1';
          if (btn) btn.disabled = false;
          specForm.submit();
        });
    });
  }

  // 选型：拖放上传区
  var zone = document.getElementById('query-dropzone');
  var input = document.getElementById('query-file-input');
  var nameEl = document.getElementById('query-file-name');
  if (!zone || !input) return;

  function setFileName(file) {
    if (!nameEl) return;
    if (!file) {
      nameEl.textContent = '尚未选择文件';
      return;
    }
    var mb = (file.size / (1024 * 1024)).toFixed(2);
    nameEl.textContent = '已选择：' + file.name + '（' + mb + ' MB）';
  }

  function assignFile(file) {
    if (!file) return;
    try {
      var dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
    } catch (err) {
      console.warn(err);
    }
    setFileName(file);
    zone.classList.add('has-file');
  }

  zone.addEventListener('click', function (e) {
    if (e.target === input) return;
    input.click();
  });

  zone.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      input.click();
    }
  });

  input.addEventListener('change', function () {
    var f = input.files && input.files[0] ? input.files[0] : null;
    setFileName(f);
    if (f) zone.classList.add('has-file');
    else zone.classList.remove('has-file');
  });

  function onDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
    zone.classList.add('is-dragover');
  }

  function onDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    // 仅当离开整个 dropzone 时去掉高亮
    if (!zone.contains(e.relatedTarget)) {
      zone.classList.remove('is-dragover');
    }
  }

  function onDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    zone.classList.remove('is-dragover');
    var files = e.dataTransfer && e.dataTransfer.files;
    if (!files || !files.length) return;
    assignFile(files[0]);
  }

  ['dragenter', 'dragover'].forEach(function (ev) {
    zone.addEventListener(ev, onDragOver);
    input.addEventListener(ev, onDragOver);
  });
  zone.addEventListener('dragleave', onDragLeave);
  input.addEventListener('dragleave', onDragLeave);
  zone.addEventListener('drop', onDrop);
  input.addEventListener('drop', onDrop);

  // 阻止浏览器在页面其它区域直接打开拖入的文件
  ['dragover', 'drop'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (zone.contains(e.target)) return;
      e.preventDefault();
    });
  });
})();
