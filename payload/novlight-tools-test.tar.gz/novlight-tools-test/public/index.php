<?php
declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

$route = $_GET['r'] ?? 'menu';
if (!is_string($route) || !preg_match('/^[a-z_]+$/', $route)) {
    $route = 'menu';
}

switch ($route) {
    case 'login':
        if (Auth::check()) {
            header('Location: index.php?r=menu');
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid();
            $username = trim((string) ($_POST['username'] ?? ''));
            $password = (string) ($_POST['password'] ?? '');
            if ($username === '' || $password === '') {
                flash_set('error', '请输入用户名和密码');
            } elseif (Auth::attempt($pdo, $username, $password)) {
                header('Location: index.php?r=menu');
                exit;
            } else {
                flash_set('error', '用户名或密码错误');
            }
        }
        render('login', ['title' => '登录', 'flash' => flash_get()]);
        break;

    case 'logout':
        Auth::requireLogin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid();
            Auth::logout();
            header('Location: index.php?r=login');
            exit;
        }
        Auth::logout();
        header('Location: index.php?r=login');
        exit;

    case 'menu':
        Auth::requireLogin();
        render('menu', ['title' => '功能菜单', 'flash' => flash_get()]);
        break;

    case 'selection':
        Auth::requireLogin();
        $results = null;
        $queryPreview = null;
        $queryMeta = null;
        $quote = null;

        // 识图模块：会话优先，否则站点配置默认（线上为 tencent）
        // spec = 规格书参数匹配（识图大模型读参数，再按参数在产品库里打分）
        $allowedProviders = ['spec', 'tencent', 'grok'];
        $defaultProvider = 'spec';
        if (!in_array($defaultProvider, $allowedProviders, true)) {
            // mock/openai 等配置时，UI 默认仍落到腾讯（可选列表内）
            $defaultProvider = 'tencent';
        }
        $imageSearchProvider = (string) ($_SESSION['image_search_provider'] ?? $defaultProvider);
        if (!in_array($imageSearchProvider, $allowedProviders, true)) {
            $imageSearchProvider = $defaultProvider;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid();
            $action = (string) ($_POST['action'] ?? 'search');

            if ($action === 'search' && (string) ($_POST['image_search_provider'] ?? '') === 'spec') {
                $_SESSION['image_search_provider'] = 'spec';
                $runId = 0;
                try {
                    @set_time_limit(600);
                    $file = $_FILES['query_file'] ?? null;
                    if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                        throw new RuntimeException('请拖入或选择规格书文件');
                    }
                    // 浏览器转好的 PDF 页面（spec_pages[]），只收真正的图片
                    $browserPages = [];
                    $sp = $_FILES['spec_pages'] ?? null;
                    if (is_array($sp) && is_array($sp['tmp_name'] ?? null)) {
                        foreach ($sp['tmp_name'] as $k => $tmp) {
                            if ((int) ($sp['error'][$k] ?? 1) === UPLOAD_ERR_OK && is_uploaded_file($tmp) && @getimagesize($tmp) !== false) {
                                $browserPages[] = $tmp;
                            }
                        }
                    }
                    $runId = SpecRun::process($pdo, $config, $file, (int) Auth::id(), null, array_slice($browserPages, 0, 40), (string) ($_POST['spec_text'] ?? ''));
                } catch (Throwable $ex) {
                    flash_set('error', $ex->getMessage());
                    header('Location: index.php?r=' . ($runId > 0 ? 'spec_result&id=' . $runId : 'selection'));
                    exit;
                }
                header('Location: index.php?r=spec_result&id=' . $runId);
                exit;
            }

            if ($action === 'search') {
                try {
                    $postedProvider = (string) ($_POST['image_search_provider'] ?? '');
                    if (in_array($postedProvider, $allowedProviders, true)) {
                        $_SESSION['image_search_provider'] = $postedProvider;
                        $imageSearchProvider = $postedProvider;
                    }

                    if (empty($_FILES['query_file']) && empty($_FILES['query_image'])) {
                        throw new RuntimeException('请拖入或选择要检索的文件');
                    }
                    // 兼容旧字段名 query_image
                    $file = !empty($_FILES['query_file']['name'])
                        ? $_FILES['query_file']
                        : ($_FILES['query_image'] ?? null);
                    if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                        throw new RuntimeException('请拖入或选择要检索的文件');
                    }
                    $saved = Upload::saveQueryFile($file, $config);

                    // 检索路径：图片用自身；ZIP 优先用解出的预览图；文档仍传原文件（mock 忽略内容）
                    $searchPath = $config['upload_dir'] . DIRECTORY_SEPARATOR . $saved['stored_name'];
                    if (!empty($saved['preview_image'])) {
                        $searchPath = $config['upload_dir'] . DIRECTORY_SEPARATOR . $saved['preview_image'];
                    }

                    $search = new ImageSearch($config, $pdo);
                    $results = $search->searchSimilar($searchPath, 5, $imageSearchProvider);
                    if ($results === []) {
                        flash_set('error', '未找到足够相似的产品（相似度阈值 '
                            . (int) ($config['image_search']['match_threshold'] ?? 60)
                            . '%）。请换一张更清晰的产品正面图再试。');
                    }

                    $queryMeta = [
                        'stored_name' => $saved['stored_name'],
                        'original_name' => $saved['original_name'],
                        'mime' => $saved['mime'],
                        'kind' => $saved['kind'],
                        'is_image' => (bool) $saved['is_image'],
                        'note' => (string) ($saved['note'] ?? ''),
                        'zip_members' => $saved['zip_members'] ?? [],
                        'preview_image' => $saved['preview_image'] ?? null,
                        'image_search_provider' => $imageSearchProvider,
                    ];
                    $_SESSION['_last_selection'] = [
                        'preview' => $saved['is_image']
                            ? $saved['stored_name']
                            : ($saved['preview_image'] ?? null),
                        'query' => $queryMeta,
                        'results' => $results,
                    ];
                    $queryPreview = $_SESSION['_last_selection']['preview'];
                } catch (Throwable $ex) {
                    flash_set('error', $ex->getMessage());
                    header('Location: index.php?r=selection');
                    exit;
                }
            } elseif ($action === 'quote') {
                $selected = $_POST['selected'] ?? [];
                if (!is_array($selected)) {
                    $selected = [];
                }
                $last = $_SESSION['_last_selection']['results'] ?? [];
                $items = [];
                $total = 0.0;
                foreach ($selected as $idx) {
                    $i = (int) $idx;
                    if (!isset($last[$i])) {
                        continue;
                    }
                    $row = $last[$i];
                    $qty = max(1, (int) ($_POST['qty'][$i] ?? 1));
                    $line = $row['price'] * $qty;
                    $total += $line;
                    $items[] = [
                        'name' => $row['name'],
                        'model' => $row['model'],
                        'price' => $row['price'],
                        'qty' => $qty,
                        'line' => $line,
                    ];
                }
                if ($items === []) {
                    flash_set('error', '请至少勾选一个产品再生成报价');
                    header('Location: index.php?r=selection');
                    exit;
                }
                $quote = [
                    'items' => $items,
                    'total' => $total,
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $results = $last;
                $queryPreview = $_SESSION['_last_selection']['preview'] ?? null;
                $queryMeta = $_SESSION['_last_selection']['query'] ?? null;
            }
        } else {
            if (!empty($_SESSION['_last_selection'])) {
                $results = $_SESSION['_last_selection']['results'];
                $queryPreview = $_SESSION['_last_selection']['preview'] ?? null;
                $queryMeta = $_SESSION['_last_selection']['query'] ?? null;
            }
        }

        render('selection', [
            'title' => '自动选型系统',
            'flash' => flash_get(),
            'results' => $results,
            'queryPreview' => $queryPreview,
            'queryMeta' => $queryMeta,
            'quote' => $quote,
            'imageSearchProvider' => $imageSearchProvider,
            'specRuns' => SpecRun::recent($pdo, (int) Auth::id(), 8),
            'specReady' => (new SpecExtractor($config))->ready(),
        ]);
        break;

    case 'spec_result':
        Auth::requireLogin();
        $run = SpecRun::find($pdo, (int) ($_GET['id'] ?? 0), (int) Auth::id());
        if (!$run) {
            flash_set('error', '这条识别记录不存在');
            header('Location: index.php?r=selection');
            exit;
        }
        $quote = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid();
            $quote = SpecRun::quote($pdo, $run, (array) ($_POST['choice'] ?? []), (array) ($_POST['qty'] ?? []));
            if ($quote['lines'] === []) {
                flash_set('error', '请至少为一款灯选择一个型号再生成报价');
                header('Location: index.php?r=spec_result&id=' . (int) $run['id']);
                exit;
            }
            $_SESSION['_spec_quote'][(int) $run['id']] = $quote;
            if ((string) ($_POST['format'] ?? '') === 'csv') {
                SpecRun::sendCsv($quote, $run);
                exit;
            }
        }
        render('spec_result', [
            'title' => '规格书匹配结果',
            'flash' => flash_get(),
            'run' => $run,
            'products' => SpecRun::productsFor($pdo, $run),
            'quote' => $quote,
        ]);
        break;

    case 'spec_page':
        // 规格书转出的页面图片（需登录，只能看自己的记录）
        Auth::requireLogin();
        $run = SpecRun::find($pdo, (int) ($_GET['id'] ?? 0), (int) Auth::id());
        $p = (string) ($_GET['p'] ?? '');
        if (!$run || !preg_match('/^p-\d{1,3}\.jpg$/', $p) || !in_array($p, $run['pages'], true)) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        $path = SpecRun::dir($config, (int) $run['id']) . '/' . $p;
        if (!is_file($path)) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        header('Content-Type: image/jpeg');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=86400');
        readfile($path);
        exit;

    case 'catalog':
        Auth::requireLogin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Csrf::requireValid();
            try {
                if (empty($_FILES['product_image'])) {
                    throw new RuntimeException('请选择产品图片');
                }
                $saved = Upload::saveImage($_FILES['product_image'], $config);
                $name = trim((string) ($_POST['product_name'] ?? ''));
                $model = trim((string) ($_POST['product_model'] ?? ''));
                $priceYuan = (float) str_replace(',', '', (string) ($_POST['price'] ?? '0'));
                $notes = trim((string) ($_POST['notes'] ?? ''));
                $category = trim((string) ($_POST['category'] ?? ''));
                $brand = trim((string) ($_POST['brand'] ?? ''));
                $series = trim((string) ($_POST['series'] ?? ''));
                if ($name === '' || $model === '') {
                    throw new RuntimeException('请填写产品名称和型号');
                }

                $specs = $notes !== '' ? json_encode(['notes' => $notes], JSON_UNESCAPED_UNICODE) : '{}';

                $stmt = $pdo->prepare(
                    'INSERT INTO products
                    (name, model, sku, price, currency, category, brand, series, specs_json, image_stored_name, source, updated_at)
                    VALUES (:n, :m, :sku, :p, :cur, :cat, :b, :ser, :sp, :img, :src, datetime(\'now\',\'localtime\'))'
                );
                $stmt->execute([
                    ':n' => $name,
                    ':m' => $model,
                    ':sku' => $model,
                    ':p' => $priceYuan,
                    ':cur' => 'CNY',
                    ':cat' => $category,
                    ':b' => $brand,
                    ':ser' => $series,
                    ':sp' => $specs ?: '{}',
                    ':img' => $saved['stored_name'],
                    ':src' => 'manual',
                ]);
                $productId = (int) $pdo->lastInsertId();
                $row = $pdo->query('SELECT * FROM products WHERE id = ' . $productId)->fetch(PDO::FETCH_ASSOC);
                ProductParams::save($pdo, $productId, ProductParams::derive((array) $row));

                $imgStmt = $pdo->prepare(
                    'INSERT INTO product_images (product_id, stored_name, original_name, mime, is_primary)
                     VALUES (:pid, :s, :o, :m, 1)'
                );
                $imgStmt->execute([
                    ':pid' => $productId,
                    ':s' => $saved['stored_name'],
                    ':o' => $saved['original_name'],
                    ':m' => $saved['mime'],
                ]);

                $search = new ImageSearch($config, $pdo);
                $abs = $config['upload_dir'] . DIRECTORY_SEPARATOR . $saved['stored_name'];
                $indexed = $search->indexImage($abs, [
                    'product_id' => $productId,
                    'product_name' => $name,
                    'product_model' => $model,
                    'price' => $priceYuan,
                ]);

                $provider = $config['image_search_provider'] ?? 'mock';
                if ($provider === 'tencent') {
                    flash_set('ok', $indexed
                        ? '已写入灯具库，并同步到腾讯云图像搜索图库'
                        : '已写入灯具库；腾讯图库同步失败（已按 fallback_mock 忽略，请检查密钥/开通状态）');
                } else {
                    flash_set('ok', '已写入独立灯具库（products）；当前检索提供商为 ' . $provider);
                }
            } catch (Throwable $ex) {
                flash_set('error', $ex->getMessage());
            }
            header('Location: index.php?r=catalog');
            exit;
        }

        $rows = $pdo->query(
            'SELECT id, name AS product_name, model AS product_model, price,
                    image_stored_name AS stored_name, category, brand, source, created_at,
                    power, ip_rating, tags, series, cct, cri
             FROM products ORDER BY id DESC LIMIT 50'
        )->fetchAll();

        render('catalog', [
            'title' => '产品图入库',
            'flash' => flash_get(),
            'rows' => $rows,
        ]);
        break;

    case 'upload':
        // 受保护输出已上传文件（仅随机文件名，防路径穿越）
        Auth::requireLogin();
        $name = (string) ($_GET['f'] ?? '');
        if (!preg_match('/^[a-f0-9]{32}\.(jpg|jpeg|png|webp|gif|pdf|xls|xlsx|doc|docx|zip)$/i', $name)) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        $path = $config['upload_dir'] . DIRECTORY_SEPARATOR . $name;
        $realDir = realpath($config['upload_dir']);
        $real = realpath($path);
        if ($realDir === false || $real === false || strpos($real, $realDir) !== 0 || !is_file($real)) {
            http_response_code(404);
            echo 'Not found';
            exit;
        }
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $mime = Upload::detectMime($real, $ext);
        $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true);
        header('Content-Type: ' . $mime);
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=3600');
        if (!$isImage) {
            header('Content-Disposition: attachment; filename="' . basename($name) . '"');
        }
        readfile($real);
        exit;

    default:
        Auth::requireLogin();
        header('Location: index.php?r=menu');
        exit;
}
